# TunnelX – Android tunnel app (Kotlin + Compose + Xray (libXray))

Skeleton for a multi-protocol VPN/tunnel client focused on:
- VLESS (Reality / TLS)
- VMess
- Trojan
- SSH

Region groups: **Bangladesh**, **Saudi Arabia (STC)**, **Middle East**, **Global**.

## Important – Real vs Fake connect

The previous skeleton set `CONNECTED` without starting any core.  
That has been **removed**. The service now goes:

`DISCONNECTED → CONNECTING → ERROR`  
with a clear message until you integrate **libXray**.

There is **no fake success** any more.

## 1. Make it actually connect (required)

1. Build `libXray.aar` from [Xray (libXray)](https://github.com/SagerNet/Xray (libXray)) (Go + gomobile + NDK).
2. Put the AAR in `app/libs/libXray.aar`.
3. In `Application` or service init call `LibXray.setup(...)`.
4. Implement `PlatformInterface` – the key method is `openTun`.  
   `TunnelVpnService.openTun(...)` is already prepared for you.
5. Uncomment the real start block inside `TunnelVpnService.start()`.
6. Use `CommandClient` for live traffic stats.

Official reference: the Xray (libXray) Android client (SFA). Respect its license (GPLv3).

## 2. Adding real servers (Bangladesh / Saudi / all SIM)

**Never ship working free public nodes inside the APK** – they die fast and are often abused.

Recommended ways:

### A. Import at runtime (best for testing)
Paste real links into the app:
```
vless://uuid@host:443?security=reality&pbk=...&fp=chrome&sni=www.google.com&flow=xtls-rprx-vision#BD-Reality
trojan://password@host:443?security=tls&sni=www.youtube.com#SA-Trojan
ssh://user:pass@host:22#SSH-BD
```

### B. Remote update JSON (production)
Host a file like:
```json
{
  "version": 15,
  "groups": {
    "BANGLADESH": ["vless://...", "trojan://..."],
    "SAUDI_ARABIA": ["vless://...", "trojan://..."],
    "MIDDLE_EAST": ["vless://..."],
    "GLOBAL": ["vless://..."]
  }
}
```
Use `ConfigUpdater.fetch(url)`.

### C. Your own VPS
Buy a cheap VPS near the target users, install Xray/Xray (libXray) with Reality, generate links, put them in the update JSON. This is the only reliable way for “all SIM working”.

## 3. Network / SNI selector

Google / YouTube / Cloudflare / Custom only affects TLS `server_name` and WS Host.  
It helps when the server is set up for that SNI (Reality dest or fronting).  
It does **nothing** for plain SSH.

## 4. Project structure
```
TunnelX/
├─ settings.gradle.kts / build.gradle.kts
└─ app/
   ├─ build.gradle.kts            (expects libs/libXray.aar)
   └─ src/main/
      ├─ AndroidManifest.xml
      └─ java/com/example/tunnelx/
         ├─ MainActivity.kt
         ├─ ui/theme/
         ├─ ui/main/              (MainScreen + MainViewModel)
         ├─ vpn/                  (TunnelVpnService + TunnelState)
         └─ data/
            ├─ ServerConfig.kt
            ├─ DefaultServers.kt  ← BD / SA / ME placeholders
            ├─ ConfigParser.kt    ← vless / vmess / trojan / ssh
            ├─ SingBoxConfigBuilder.kt
            ├─ ServerSelector.kt  ← auto (TCP ping) + random
            └─ ConfigUpdater.kt   ← remote JSON
```

## 5. MVP checklist after libXray

- [x] No fake CONNECTED
- [x] Region groups (BD, SA-STC, ME, Global)
- [x] Network / SNI selector
- [x] Link + clipboard import parser
- [x] Auto / Random server selection
- [ ] Real libXray start/stop + TUN
- [ ] Live traffic stats from core
- [ ] Persist imported servers (DataStore / Room)
- [ ] QR import
- [ ] Online config update button
- [ ] Logs screen

## 6. Play Store notes

- Declare `VpnService` and a real Privacy Policy.
- Do not log user traffic.
- Free public nodes inside the APK will get you bad reviews when they die.

## GitHub Actions (SA TUNNEL style)

1. Push this project (or the ZIP) to a GitHub repo.
2. Add the workflow YAML under `.github/workflows/build.yml`.
3. The workflow:
   - finds `app/build.gradle.kts` + `build_core.sh`
   - builds `libXray.aar`
   - runs `gradle :app:assembleDebug`
   - uploads `app-debug.apk` as artifact

Required in project root:
- `build_core.sh` (executable)
- `settings.gradle.kts`
- `app/build.gradle.kts`
