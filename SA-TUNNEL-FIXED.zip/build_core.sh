#!/usr/bin/env bash
# Build or fetch libXray / libv2ray AAR for SA TUNNEL
# Output: app/libs/libXray.aar  (and libv2ray.aar copy)
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
LIBS="$ROOT/app/libs"
mkdir -p "$LIBS"

echo "==> Preparing libXray AAR"

# ------------------------------------------------------------------
# Option A (preferred): download official release AAR — fast & reliable
# ------------------------------------------------------------------
download_release() {
  echo "Trying download from 2dust/AndroidLibXrayLite releases..."
  local api="https://api.github.com/repos/2dust/AndroidLibXrayLite/releases/latest"
  local url
  url="$(curl -fsSL "$api" | python3 -c '
import sys, json
data = json.load(sys.stdin)
for a in data.get("assets", []):
    name = a.get("name", "")
    if name.endswith(".aar") and "source" not in name.lower():
        print(a["browser_download_url"])
        break
' 2>/dev/null || true)"

  if [ -z "${url:-}" ]; then
    # fallback: known asset name pattern
    url="https://github.com/2dust/AndroidLibXrayLite/releases/latest/download/libv2ray.aar"
  fi

  echo "Downloading: $url"
  if curl -fL --retry 3 -o "$LIBS/libv2ray.aar" "$url"; then
    if [ -s "$LIBS/libv2ray.aar" ]; then
      cp -f "$LIBS/libv2ray.aar" "$LIBS/libXray.aar"
      ls -la "$LIBS/libv2ray.aar" "$LIBS/libXray.aar"
      echo "==> AAR ready (downloaded)"
      return 0
    fi
  fi
  return 1
}

# ------------------------------------------------------------------
# Option B: build from source (official instructions)
# ------------------------------------------------------------------
build_from_source() {
  echo "Building AndroidLibXrayLite from source..."
  command -v go >/dev/null || { echo "ERROR: go not found"; return 1; }
  command -v java >/dev/null || { echo "ERROR: java not found"; return 1; }

  export PATH="${PATH}:$(go env GOPATH)/bin"
  go install golang.org/x/mobile/cmd/gomobile@latest
  go install golang.org/x/mobile/cmd/gobind@latest

  local WORKDIR
  WORKDIR="${TMPDIR:-/tmp}/AndroidLibXrayLite-build-$$"
  rm -rf "$WORKDIR"
  git clone --depth 1 https://github.com/2dust/AndroidLibXrayLite.git "$WORKDIR"
  cd "$WORKDIR"

  # geo assets (required by upstream CI)
  mkdir -p assets data
  if [ -f gen_assets.sh ]; then
    chmod +x gen_assets.sh
    bash gen_assets.sh download || true
    cp -v data/*.dat assets/ 2>/dev/null || true
  fi

  # NDK must be visible
  if [ -z "${ANDROID_NDK_HOME:-}" ] && [ -n "${ANDROID_HOME:-}" ]; then
    local ndk
    ndk="$(ls -d "$ANDROID_HOME"/ndk/* 2>/dev/null | sort -V | tail -n 1 || true)"
    if [ -n "$ndk" ]; then
      export ANDROID_NDK_HOME="$ndk"
      export ANDROID_NDK_ROOT="$ndk"
    fi
  fi
  echo "ANDROID_NDK_HOME=${ANDROID_NDK_HOME:-not set}"

  gomobile init
  go mod tidy -v

  # Official bind flags from AndroidLibXrayLite README / CI
  gomobile bind -v -androidapi 24 -trimpath \
    -ldflags='-s -w -buildid= -checklinkname=0' ./

  local AAR
  AAR="$(find . -maxdepth 1 -name 'libv2ray.aar' -o -name 'libXray.aar' -o -name '*.aar' | head -n 1 || true)"
  if [ -z "$AAR" ] || [ ! -s "$AAR" ]; then
    echo "ERROR: gomobile bind produced no AAR"
    ls -la
    return 1
  fi

  cp -f "$AAR" "$LIBS/libv2ray.aar"
  cp -f "$AAR" "$LIBS/libXray.aar"
  ls -la "$LIBS/libv2ray.aar" "$LIBS/libXray.aar"
  echo "==> AAR ready (built from source)"
  return 0
}

# Try download first, then source build
if download_release; then
  exit 0
fi

echo "Download failed — falling back to source build..."
if build_from_source; then
  exit 0
fi

echo "ERROR: Failed to produce libXray.aar / libv2ray.aar"
exit 1
