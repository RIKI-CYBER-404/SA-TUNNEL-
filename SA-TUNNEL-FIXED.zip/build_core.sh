#!/usr/bin/env bash
# Build official AndroidLibXrayLite AAR for SA TUNNEL / TunnelX
# Expected output: app/libs/libXray.aar
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
LIBS="$ROOT/app/libs"
mkdir -p "$LIBS"

echo "==> Building libXray.aar (AndroidLibXrayLite)"

# Use a known working tag/commit of 2dust/AndroidLibXrayLite
REPO_URL="https://github.com/2dust/AndroidLibXrayLite.git"
WORKDIR="${TMPDIR:-/tmp}/AndroidLibXrayLite-build-$$"
rm -rf "$WORKDIR"
git clone --depth 1 "$REPO_URL" "$WORKDIR"
cd "$WORKDIR"

# Prefer gomobile path used by the project
export PATH="$PATH:$(go env GOPATH)/bin"
go install golang.org/x/mobile/cmd/gomobile@latest || true
gomobile init || true

# Build AAR (script may differ by version; try common targets)
if [ -f ./build.sh ]; then
  chmod +x ./build.sh
  ./build.sh || true
fi

# Fallback: direct gomobile bind if build.sh is missing / fails
if [ ! -f libXray.aar ] && [ ! -f app/libs/libXray.aar ]; then
  echo "Trying gomobile bind fallback..."
  # Typical package path in AndroidLibXrayLite
  if [ -d libv2ray ]; then
    gomobile bind -v -androidapi 24 -o libXray.aar ./libv2ray || true
  fi
fi

# Locate produced AAR
AAR="$(find . -name 'libXray.aar' -o -name 'libv2ray.aar' -o -name '*.aar' | head -n 1 || true)"
if [ -z "$AAR" ] || [ ! -s "$AAR" ]; then
  echo "ERROR: Failed to produce libXray.aar"
  find . -type f -name '*.aar' -o -name 'build*' | head -50
  exit 1
fi

cp -f "$AAR" "$LIBS/libXray.aar"
ls -la "$LIBS/libXray.aar"
echo "==> libXray.aar ready at app/libs/libXray.aar"
