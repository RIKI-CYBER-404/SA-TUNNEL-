placeholder - replaced by build_core.sh
