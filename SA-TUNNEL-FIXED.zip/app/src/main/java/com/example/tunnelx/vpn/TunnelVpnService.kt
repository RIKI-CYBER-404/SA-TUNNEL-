package com.example.tunnelx.vpn

import android.app.*
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import kotlinx.coroutines.*

/**
 * Real connection requires Xray (libXray) libXray.aar (see README).
 * Until libXray is integrated this service will NOT fake a connected state.
 * It stays in CONNECTING then moves to ERROR with a clear message so the
 * UI never shows a false "CONNECTED".
 */
class TunnelVpnService : VpnService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var statsJob: Job? = null
    private var tunFd: ParcelFileDescriptor? = null
    // private var boxService: Any? = null   // LibXray service instance

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val json = intent.getStringExtra(EXTRA_CONFIG_JSON)
                if (json.isNullOrBlank()) {
                    fail("Empty config JSON")
                    return START_NOT_STICKY
                }
                start(json)
            }
            ACTION_STOP -> stop()
        }
        return START_STICKY
    }

    private fun start(configJson: String) {
        startForeground(1, notification("Connecting…"))
        TunnelState.lastError.value = null
        TunnelState.conn.value = ConnState.CONNECTING

        scope.launch {
            try {
                // -------------------------------------------------------
                // REAL IMPLEMENTATION (uncomment after adding libXray.aar)
                // -------------------------------------------------------
                // 1. PlatformInterface that calls this.openTun(...)
                // 2. val svc = LibXray.newService(configJson, platformInterface)
                // 3. svc.start()
                // 4. boxService = svc
                // 5. TunnelState.connectedAtMs.value = System.currentTimeMillis()
                // 6. TunnelState.conn.value = ConnState.CONNECTED
                // 7. startForeground(1, notification("Connected"))
                // 8. statsJob = launch { pollStatsFromLibXray() }
                // -------------------------------------------------------

                // Current behaviour: refuse to fake success.
                delay(800) // small delay so UI shows CONNECTING
                fail(
                    "Core not integrated. Add libXray.aar and implement " +
                    "PlatformInterface + LibXray.newService (see README §3). " +
                    "Import real vless/trojan/ssh links after that."
                )
            } catch (e: Exception) {
                fail(e.message ?: "Unknown start error")
            }
        }
    }

    private fun fail(msg: String) {
        TunnelState.lastError.value = msg
        TunnelState.conn.value = ConnState.ERROR
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private suspend fun pollStatsFromLibXray() {
        // Replace with libXray CommandClient traffic callbacks.
        // Example shape the UI expects:
        // TunnelState.traffic.value = Traffic(upBps, downBps, upTotal, downTotal)
        while (true) delay(1000)
    }

    private fun stop() {
        statsJob?.cancel()
        // (boxService as? AutoCloseable)?.close()
        // boxService = null
        runCatching { tunFd?.close() }
        tunFd = null
        TunnelState.conn.value = ConnState.DISCONNECTED
        TunnelState.traffic.value = Traffic()
        TunnelState.connectedAtMs.value = 0L
        TunnelState.lastError.value = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onRevoke() = stop()
    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    /** Called by PlatformInterface when libXray asks for a TUN. */
    fun openTun(
        address: String = "172.19.0.1",
        prefix: Int = 30,
        mtu: Int = 9000,
        dns: String = "1.1.1.1"
    ): Int {
        val builder = Builder()
            .setSession("TunnelX")
            .setMtu(mtu)
            .addAddress(address, prefix)
            .addRoute("0.0.0.0", 0)
            .addDnsServer(dns)
            .addDisallowedApplication(packageName) // prevent loop
        if (Build.VERSION.SDK_INT >= 29) builder.setMetered(false)
        val pfd = builder.establish() ?: throw IllegalStateException("VpnService.Builder.establish() returned null")
        tunFd = pfd
        return pfd.detachFd()
    }

    private fun notification(text: String): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel("vpn", "VPN", NotificationManager.IMPORTANCE_LOW)
            )
        }
        return Notification.Builder(this, "vpn")
            .setContentTitle("TunnelX")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setOngoing(true)
            .build()
    }

    companion object {
        const val ACTION_START = "start"
        const val ACTION_STOP = "stop"
        const val EXTRA_CONFIG_JSON = "cfg"
    }
}
