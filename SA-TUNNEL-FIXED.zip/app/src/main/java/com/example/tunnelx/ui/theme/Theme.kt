package com.example.tunnelx.ui.theme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
private val Scheme = darkColorScheme(
    primary = Neon, onPrimary = NavyBg, background = NavyBg, onBackground = TextPrimary,
    surface = NavySurface, onSurface = TextPrimary, surfaceVariant = NavyCard, onSurfaceVariant = TextMuted,
    error = Danger, outline = NeonDim)
@Composable fun TunnelTheme(content: @Composable () -> Unit) = MaterialTheme(colorScheme = Scheme, content = content)
