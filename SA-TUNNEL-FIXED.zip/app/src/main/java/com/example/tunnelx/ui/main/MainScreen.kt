package com.example.tunnelx.ui.main
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import com.example.tunnelx.data.*
import com.example.tunnelx.ui.theme.*
import com.example.tunnelx.vpn.ConnState

@Composable
fun MainScreen(vm: MainViewModel, onToggle: (active: Boolean) -> Unit) {
    val ui by vm.ui.collectAsState(); val conn by vm.conn.collectAsState()
    val t by vm.traffic.collectAsState(); val secs by vm.seconds.collectAsState(0L)
    var tab by remember { mutableIntStateOf(0) }
    var picker by remember { mutableStateOf<String?>(null) }   // "location" | "network"

    Scaffold(containerColor = NavyBg, bottomBar = { BottomBar(tab) { tab = it } }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("TunnelX", color = Neon, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(20.dp))

            InfoBox(Icons.Default.Public, "Location",
                if (ui.auto) "Auto Select • ${ui.region.label}" else ui.selected?.name ?: "Select server") { picker = "location" }
            Spacer(Modifier.height(12.dp))
            InfoBox(Icons.Default.Wifi, "Network",
                if (ui.network == NetworkPreset.CUSTOM) ui.customSni.ifBlank { "Custom SNI" } else ui.network.label) { picker = "network" }

            Spacer(Modifier.weight(1f))
            PowerButton(conn) { onToggle(conn != ConnState.DISCONNECTED) }
            Spacer(Modifier.height(14.dp))
            val err by vm.lastError.collectAsState()
            Text(when (conn) {
                    ConnState.DISCONNECTED -> "Tap to connect"
                    ConnState.CONNECTING -> "Connecting…"
                    ConnState.CONNECTED -> "Connected"
                    ConnState.ERROR -> (err ?: "Error").take(80)
                },
                color = when (conn) {
                    ConnState.CONNECTED -> Neon
                    ConnState.ERROR -> Color(0xFFFF5252)
                    else -> TextMuted
                }, fontSize = 14.sp)
            Spacer(Modifier.weight(1f))

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Stat("Upload", fmt(t.upBps) + "/s", Modifier.weight(1f))
                Stat("Download", fmt(t.downBps) + "/s", Modifier.weight(1f))
                Stat("Time", "%02d:%02d:%02d".format(secs / 3600, secs / 60 % 60, secs % 60), Modifier.weight(1f))
            }
            Spacer(Modifier.height(8.dp))
        }
    }

    if (picker == "location") LocationSheet(ui, vm) { picker = null }
    if (picker == "network") NetworkSheet(ui, vm) { picker = null }
}

@Composable
private fun PowerButton(state: ConnState, onClick: () -> Unit) {
    val pulse by rememberInfiniteTransition(label = "p").animateFloat(0.4f, 1f,
        infiniteRepeatable(tween(1200), RepeatMode.Reverse), label = "a")
    val on = state != ConnState.DISCONNECTED
    Box(Modifier.size(210.dp).clip(CircleShape)
        .background(Brush.radialGradient(listOf(if (on) Neon.copy(alpha = 0.35f * pulse) else Color.Transparent, Color.Transparent))),
        contentAlignment = Alignment.Center) {
        Box(Modifier.size(150.dp).clip(CircleShape).background(NavyCard)
            .border(4.dp, if (on) Neon else NeonDim.copy(alpha = 0.5f), CircleShape).clickable(onClick = onClick),
            contentAlignment = Alignment.Center) {
            Icon(Icons.Default.PowerSettingsNew, null, tint = if (on) Neon else TextMuted, modifier = Modifier.size(64.dp))
        }
    }
}

@Composable
private fun InfoBox(icon: ImageVector, label: String, value: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(NavyCard)
        .border(1.dp, NeonDim.copy(alpha = 0.4f), RoundedCornerShape(16.dp)).clickable(onClick = onClick).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Neon); Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) { Text(label, color = TextMuted, fontSize = 12.sp); Text(value, color = TextPrimary, fontSize = 16.sp) }
        Icon(Icons.Default.KeyboardArrowDown, null, tint = TextMuted)
    }
}

@Composable
private fun Stat(label: String, value: String, mod: Modifier) {
    Column(mod.clip(RoundedCornerShape(14.dp)).background(NavySurface).padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = TextMuted, fontSize = 12.sp); Spacer(Modifier.height(4.dp))
        Text(value, color = Neon, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun BottomBar(sel: Int, onSel: (Int) -> Unit) {
    val items = listOf("Home" to Icons.Default.Home, "Servers" to Icons.Default.Dns, "Import" to Icons.Default.Add, "Settings" to Icons.Default.Settings)
    NavigationBar(containerColor = NavySurface) {
        items.forEachIndexed { i, (l, ic) ->
            NavigationBarItem(selected = sel == i, onClick = { onSel(i) }, icon = { Icon(ic, l) }, label = { Text(l) },
                colors = NavigationBarItemDefaults.colors(selectedIconColor = NavyBg, indicatorColor = Neon,
                    unselectedIconColor = TextMuted, selectedTextColor = Neon, unselectedTextColor = TextMuted))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LocationSheet(ui: UiState, vm: MainViewModel, close: () -> Unit) = ModalBottomSheet(close, containerColor = NavySurface) {
    Column(Modifier.padding(16.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(ui.auto, { vm.setAuto(true) }, { Text("Auto Select") })
            AssistChip({ vm.random(); close() }, { Text("Random") })
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Region.values().forEach { r -> FilterChip(ui.region == r, { vm.setRegion(r) }, { Text(r.label) }) }
        }
        Spacer(Modifier.height(8.dp))
        ui.servers.filter { it.region == ui.region }.forEach { s ->
            ListItem(headlineContent = { Text(s.name) }, supportingContent = { Text("${s.protocol} • ${s.host}") },
                trailingContent = { s.latencyMs?.let { Text("$it ms", color = Neon) } },
                colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                modifier = Modifier.clickable { vm.pick(s); close() })
        }
        Spacer(Modifier.height(24.dp))
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NetworkSheet(ui: UiState, vm: MainViewModel, close: () -> Unit) = ModalBottomSheet(close, containerColor = NavySurface) {
    Column(Modifier.padding(16.dp)) {
        NetworkPreset.values().forEach { n ->
            ListItem(headlineContent = { Text(n.label) }, supportingContent = { n.sni?.let { Text(it) } },
                leadingContent = { RadioButton(ui.network == n, { vm.setNetwork(n); if (n != NetworkPreset.CUSTOM) close() }) },
                colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                modifier = Modifier.clickable { vm.setNetwork(n); if (n != NetworkPreset.CUSTOM) close() })
        }
        if (ui.network == NetworkPreset.CUSTOM)
            OutlinedTextField(ui.customSni, vm::setCustomSni, label = { Text("SNI / Host") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(24.dp))
    }
}

private fun fmt(b: Long): String = when {
    b >= 1_048_576 -> "%.1f MB".format(b / 1_048_576.0)
    b >= 1024 -> "%.0f KB".format(b / 1024.0)
    else -> "$b B"
}
