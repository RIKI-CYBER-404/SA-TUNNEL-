package com.example.tunnelx.ui.theme
import androidx.compose.ui.graphics.Color
val NavyBg = Color(0xFF0A1428)
val NavySurface = Color(0xFF111E3A)
val NavyCard = Color(0xFF16264A)
val Neon = Color(0xFF39FF88)
val NeonDim = Color(0xFF1FA85A)
val TextPrimary = Color(0xFFEAF1FF)
val TextMuted = Color(0xFF8FA3C7)
val Danger = Color(0xFFFF5C6C)
