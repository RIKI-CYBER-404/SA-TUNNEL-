package com.example.tunnelx.ui.main

import android.app.Application
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.tunnelx.data.*
import com.example.tunnelx.vpn.*
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class UiState(
    val servers: List<ServerConfig> = emptyList(),
    val selected: ServerConfig? = null,
    val auto: Boolean = true,
    val region: Region = Region.GLOBAL,
    val network: NetworkPreset = NetworkPreset.GOOGLE,
    val customSni: String = ""
)

@OptIn(ExperimentalCoroutinesApi::class)
class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val _ui = MutableStateFlow(UiState())
    val ui = _ui.asStateFlow()
    val conn = TunnelState.conn
    val traffic = TunnelState.traffic
    val lastError = TunnelState.lastError

    val seconds = combine(TunnelState.conn, TunnelState.connectedAtMs) { c, t -> c to t }
        .flatMapLatest { (c, t) ->
            if (c == ConnState.CONNECTED) flow {
                while (true) {
                    emit((System.currentTimeMillis() - t) / 1000)
                    delay(1000)
                }
            } else flowOf(0L)
        }

    init {
        // Load region-aware placeholders so UI is not empty.
        // Replace with real links via import() or ConfigUpdater.
        _ui.update { it.copy(servers = DefaultServers.all()) }
    }

    fun import(text: String) {
        val list = ConfigParser.parseMany(text)
        if (list.isEmpty()) return
        _ui.update { it.copy(servers = it.servers + list) }
    }

    fun setRegion(r: Region) = _ui.update { it.copy(region = r) }
    fun setNetwork(n: NetworkPreset) = _ui.update { it.copy(network = n) }
    fun setCustomSni(s: String) = _ui.update { it.copy(customSni = s) }
    fun setAuto(b: Boolean) = _ui.update { it.copy(auto = b) }
    fun pick(s: ServerConfig) = _ui.update { it.copy(selected = s, auto = false) }
    fun random() {
        ServerSelector.random(pool())?.let { pick(it) }
    }

    private fun pool() = _ui.value.servers
        .filter { it.region == _ui.value.region }
        .ifEmpty { _ui.value.servers }
        .filter { it.host != "0.0.0.0" && !it.host.startsWith("REPLACE") }

    /** Call after VPN permission is granted. */
    fun connect() = viewModelScope.launch {
        val st = _ui.value
        val server = (if (st.auto) ServerSelector.auto(pool()) else st.selected)
            ?: run {
                TunnelState.lastError.value = "No usable server in current region. Import real vless/trojan/ssh links first."
                TunnelState.conn.value = ConnState.ERROR
                return@launch
            }
        _ui.update { it.copy(selected = server) }
        val sni = if (st.network == NetworkPreset.CUSTOM) st.customSni.ifBlank { null } else st.network.sni
        val json = SingBoxConfigBuilder.build(server, sni)
        getApplication<Application>().startForegroundService(
            Intent(getApplication(), TunnelVpnService::class.java)
                .setAction(TunnelVpnService.ACTION_START)
                .putExtra(TunnelVpnService.EXTRA_CONFIG_JSON, json)
        )
    }

    fun disconnect() {
        getApplication<Application>().startService(
            Intent(getApplication(), TunnelVpnService::class.java)
                .setAction(TunnelVpnService.ACTION_STOP)
        )
    }

    fun clearError() {
        if (TunnelState.conn.value == ConnState.ERROR) {
            TunnelState.conn.value = ConnState.DISCONNECTED
            TunnelState.lastError.value = null
        }
    }
}
