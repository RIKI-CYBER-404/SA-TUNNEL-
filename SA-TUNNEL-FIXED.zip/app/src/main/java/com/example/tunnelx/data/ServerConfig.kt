package com.example.tunnelx.data
import java.util.UUID

enum class Protocol { VLESS, VMESS, TROJAN, SSH }
enum class Region(val label: String) { BANGLADESH("Bangladesh"), SAUDI_ARABIA("Saudi Arabia (STC)"), MIDDLE_EAST("Middle East"), GLOBAL("Global") }

/** Network presets = the SNI / camouflage host selector on the main screen. */
enum class NetworkPreset(val label: String, val sni: String?) {
    GOOGLE("Google", "www.google.com"), YOUTUBE("YouTube", "www.youtube.com"),
    CLOUDFLARE("Cloudflare", "www.cloudflare.com"), CUSTOM("Custom SNI", null)
}

data class ServerConfig(
    val id: String = UUID.randomUUID().toString(),
    val name: String, val protocol: Protocol, val host: String, val port: Int,
    val region: Region = Region.GLOBAL,
    val uuid: String? = null,            // VLESS / VMess id
    val username: String? = null,        // SSH
    val password: String? = null,        // Trojan / SSH
    val transport: String = "tcp",       // tcp | ws | grpc
    val security: String = "none",       // none | tls | reality
    val sni: String? = null, val fingerprint: String = "chrome",
    val flow: String? = null, val publicKey: String? = null, val shortId: String? = null,
    val path: String? = null, val hostHeader: String? = null, val serviceName: String? = null,
    val alterId: Int = 0, val vmessCipher: String = "auto",
    val latencyMs: Int? = null
)
