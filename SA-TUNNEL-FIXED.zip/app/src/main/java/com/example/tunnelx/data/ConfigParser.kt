package com.example.tunnelx.data
import android.net.Uri
import android.util.Base64
import org.json.JSONObject

object ConfigParser {
    fun parseMany(text: String): List<ServerConfig> {
        val raw = text.trim()
        // Subscription bodies are often one big base64 blob of links
        val body = if (!raw.contains("://")) runCatching { decodeB64(raw) }.getOrDefault(raw) else raw
        return body.lines().map { it.trim() }.filter { it.isNotEmpty() }.mapNotNull { parse(it) }
    }

    fun parse(link: String): ServerConfig? = runCatching {
        when {
            link.startsWith("vless://") -> vless(link)
            link.startsWith("vmess://") -> vmess(link)
            link.startsWith("trojan://") -> trojan(link)
            link.startsWith("ssh://") -> ssh(link)
            else -> null
        }
    }.getOrNull()

    private fun vless(link: String): ServerConfig {
        val u = Uri.parse(link)
        fun q(k: String) = u.getQueryParameter(k)
        return ServerConfig(
            name = u.fragment ?: u.host!!, protocol = Protocol.VLESS, host = u.host!!, port = u.port,
            uuid = u.userInfo, transport = q("type") ?: "tcp", security = q("security") ?: "none",
            sni = q("sni"), fingerprint = q("fp") ?: "chrome", flow = q("flow"),
            publicKey = q("pbk"), shortId = q("sid"), path = q("path"), hostHeader = q("host"),
            serviceName = q("serviceName"))
    }

    private fun vmess(link: String): ServerConfig {
        val j = JSONObject(decodeB64(link.removePrefix("vmess://")))
        return ServerConfig(
            name = j.optString("ps", j.getString("add")), protocol = Protocol.VMESS,
            host = j.getString("add"), port = j.get("port").toString().toInt(),
            uuid = j.getString("id"), alterId = j.optString("aid", "0").toIntOrNull() ?: 0,
            vmessCipher = j.optString("scy", "auto").ifEmpty { "auto" },
            transport = j.optString("net", "tcp"), security = if (j.optString("tls") == "tls") "tls" else "none",
            sni = j.optString("sni").ifEmpty { null }, hostHeader = j.optString("host").ifEmpty { null },
            path = j.optString("path").ifEmpty { null }, fingerprint = j.optString("fp", "chrome").ifEmpty { "chrome" })
    }

    private fun trojan(link: String): ServerConfig {
        val u = Uri.parse(link)
        return ServerConfig(
            name = u.fragment ?: u.host!!, protocol = Protocol.TROJAN, host = u.host!!, port = u.port,
            password = u.userInfo, security = "tls", sni = u.getQueryParameter("sni") ?: u.getQueryParameter("peer"),
            transport = u.getQueryParameter("type") ?: "tcp", path = u.getQueryParameter("path"),
            hostHeader = u.getQueryParameter("host"))
    }

    // ssh://user:pass@host:port#name
    private fun ssh(link: String): ServerConfig {
        val u = Uri.parse(link)
        val parts = (u.userInfo ?: "").split(":", limit = 2)
        return ServerConfig(name = u.fragment ?: u.host!!, protocol = Protocol.SSH, host = u.host!!,
            port = if (u.port > 0) u.port else 22, username = parts[0], password = parts.getOrNull(1))
    }

    private fun decodeB64(s: String): String {
        val clean = s.trim().replace('-', '+').replace('_', '/')
        return String(Base64.decode(clean, Base64.DEFAULT or Base64.NO_WRAP))
    }
}
