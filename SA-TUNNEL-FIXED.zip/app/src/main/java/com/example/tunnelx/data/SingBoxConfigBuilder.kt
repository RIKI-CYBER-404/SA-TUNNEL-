package com.example.tunnelx.data
import org.json.JSONArray
import org.json.JSONObject

/** Turns a ServerConfig into a full sing-box JSON config (tun inbound + proxy outbound).
 *  Field names follow sing-box 1.10+; check the docs for the exact libbox version you build. */
object SingBoxConfigBuilder {
    fun build(s: ServerConfig, sniOverride: String?): String {
        val proxy = JSONObject().put("tag", "proxy").put("server", s.host).put("server_port", s.port)
        when (s.protocol) {
            Protocol.VLESS -> { proxy.put("type", "vless").put("uuid", s.uuid); s.flow?.let { proxy.put("flow", it) } }
            Protocol.VMESS -> proxy.put("type", "vmess").put("uuid", s.uuid).put("security", s.vmessCipher).put("alter_id", s.alterId)
            Protocol.TROJAN -> proxy.put("type", "trojan").put("password", s.password)
            Protocol.SSH -> proxy.put("type", "ssh").put("user", s.username).put("password", s.password)
        }
        if (s.protocol != Protocol.SSH) {
            if (s.security != "none") {
                val tls = JSONObject().put("enabled", true).put("server_name", sniOverride ?: s.sni ?: s.host)
                    .put("utls", JSONObject().put("enabled", true).put("fingerprint", s.fingerprint))
                if (s.security == "reality")
                    tls.put("reality", JSONObject().put("enabled", true).put("public_key", s.publicKey).put("short_id", s.shortId ?: ""))
                proxy.put("tls", tls)
            }
            when (s.transport) {
                "ws" -> proxy.put("transport", JSONObject().put("type", "ws").put("path", s.path ?: "/")
                    .put("headers", JSONObject().put("Host", sniOverride ?: s.hostHeader ?: s.host)))
                "grpc" -> proxy.put("transport", JSONObject().put("type", "grpc").put("service_name", s.serviceName ?: ""))
            }
        }
        val root = JSONObject()
            .put("log", JSONObject().put("level", "warn"))
            .put("dns", JSONObject().put("servers", JSONArray().put(JSONObject().put("tag", "remote").put("address", "https://1.1.1.1/dns-query").put("detour", "proxy"))))
            .put("inbounds", JSONArray().put(JSONObject().put("type", "tun").put("address", JSONArray().put("172.19.0.1/30"))
                .put("auto_route", true).put("strict_route", true).put("stack", "mixed")))
            .put("outbounds", JSONArray().put(proxy).put(JSONObject().put("type", "direct").put("tag", "direct")))
            .put("route", JSONObject().put("auto_detect_interface", true).put("final", "proxy"))
        return root.toString()
    }
}
