package com.example.tunnelx
import android.net.VpnService
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import com.example.tunnelx.ui.main.*
import com.example.tunnelx.ui.theme.TunnelTheme

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TunnelTheme {
                val permission = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
                    if (r.resultCode == RESULT_OK) vm.connect()
                }
                MainScreen(vm, onToggle = { active ->
                    if (active) vm.disconnect()
                    else VpnService.prepare(this)?.let { permission.launch(it) } ?: vm.connect()
                })
            }
        }
    }
}
