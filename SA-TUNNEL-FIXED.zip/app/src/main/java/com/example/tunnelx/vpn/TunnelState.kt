package com.example.tunnelx.vpn
import kotlinx.coroutines.flow.MutableStateFlow

enum class ConnState { DISCONNECTED, CONNECTING, CONNECTED, ERROR }

data class Traffic(
    val upBps: Long = 0,
    val downBps: Long = 0,
    val upTotal: Long = 0,
    val downTotal: Long = 0
)

/** Process-wide state the service writes and the UI reads. */
object TunnelState {
    val conn = MutableStateFlow(ConnState.DISCONNECTED)
    val traffic = MutableStateFlow(Traffic())
    val connectedAtMs = MutableStateFlow(0L)
    /** Last error message when conn == ERROR (shown on main screen). */
    val lastError = MutableStateFlow<String?>(null)
}
