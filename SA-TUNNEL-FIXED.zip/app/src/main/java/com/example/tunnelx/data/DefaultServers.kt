package com.example.tunnelx.data

/**
 * Placeholder / example servers for Bangladesh, Saudi Arabia (STC focus), Middle East and Global.
 *
 * IMPORTANT:
 * - These are EXAMPLE shapes only. Free public nodes die quickly and may be insecure.
 * - For real working connections you MUST replace the uuid/password/publicKey with
 *   your own VPS Reality / Trojan / SSH credentials or a paid subscription.
 * - After integrating libbox (see README) paste real vless:// trojan:// ssh:// links
 *   via the Import / Clipboard feature or load them through ConfigUpdater.
 *
 * Network / SNI (Google, YouTube, Cloudflare) only helps when the server is
 * configured for that SNI (Reality dest or WS Host). It does nothing for pure SSH.
 */
object DefaultServers {

    fun all(): List<ServerConfig> = bangladesh() + saudi() + middleEast() + global()

    fun bangladesh(): List<ServerConfig> = listOf(
        // Example VLESS Reality shape – REPLACE credentials
        ServerConfig(
            name = "BD • VLESS Reality (example)",
            protocol = Protocol.VLESS,
            host = "REPLACE_WITH_YOUR_BD_OR_NEAREST_HOST",
            port = 443,
            region = Region.BANGLADESH,
            uuid = "00000000-0000-0000-0000-000000000000",
            transport = "tcp",
            security = "reality",
            sni = "www.microsoft.com",
            fingerprint = "chrome",
            flow = "xtls-rprx-vision",
            publicKey = "REPLACE_PUBLIC_KEY",
            shortId = ""
        ),
        ServerConfig(
            name = "BD • Trojan TLS (example)",
            protocol = Protocol.TROJAN,
            host = "REPLACE_WITH_YOUR_HOST",
            port = 443,
            region = Region.BANGLADESH,
            password = "REPLACE_PASSWORD",
            transport = "tcp",
            security = "tls",
            sni = "www.google.com"
        )
    )

    fun saudi(): List<ServerConfig> = listOf(
        // STC / Saudi friendly – Reality or Trojan with strong SNI usually works better
        ServerConfig(
            name = "SA-STC • VLESS Reality (example)",
            protocol = Protocol.VLESS,
            host = "REPLACE_WITH_YOUR_SA_HOST",
            port = 443,
            region = Region.SAUDI_ARABIA,
            uuid = "00000000-0000-0000-0000-000000000000",
            transport = "tcp",
            security = "reality",
            sni = "www.google.com",
            fingerprint = "chrome",
            flow = "xtls-rprx-vision",
            publicKey = "REPLACE_PUBLIC_KEY",
            shortId = ""
        ),
        ServerConfig(
            name = "SA-STC • Trojan (example)",
            protocol = Protocol.TROJAN,
            host = "REPLACE_WITH_YOUR_HOST",
            port = 443,
            region = Region.SAUDI_ARABIA,
            password = "REPLACE_PASSWORD",
            security = "tls",
            sni = "www.youtube.com"
        )
    )

    fun middleEast(): List<ServerConfig> = listOf(
        ServerConfig(
            name = "ME • VLESS Reality (example)",
            protocol = Protocol.VLESS,
            host = "REPLACE_WITH_YOUR_ME_HOST",
            port = 443,
            region = Region.MIDDLE_EAST,
            uuid = "00000000-0000-0000-0000-000000000000",
            transport = "tcp",
            security = "reality",
            sni = "www.cloudflare.com",
            fingerprint = "chrome",
            flow = "xtls-rprx-vision",
            publicKey = "REPLACE_PUBLIC_KEY",
            shortId = ""
        )
    )

    fun global(): List<ServerConfig> = listOf(
        // Keep empty or add your own global nodes. Prefer subscription update.
        ServerConfig(
            name = "Global • Import your own",
            protocol = Protocol.VLESS,
            host = "0.0.0.0",
            port = 443,
            region = Region.GLOBAL,
            uuid = "00000000-0000-0000-0000-000000000000",
            security = "reality",
            publicKey = "REPLACE"
        )
    )
}
