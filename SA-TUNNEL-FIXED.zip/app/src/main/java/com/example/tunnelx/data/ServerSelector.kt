package com.example.tunnelx.data
import kotlinx.coroutines.*
import java.net.InetSocketAddress
import java.net.Socket

object ServerSelector {
    /** TCP connect latency; good enough for MVP. Later: real URL test through the core. */
    suspend fun ping(s: ServerConfig, timeoutMs: Int = 2500): Int? = withContext(Dispatchers.IO) {
        runCatching {
            val t = System.nanoTime()
            Socket().use { it.connect(InetSocketAddress(s.host, s.port), timeoutMs) }
            ((System.nanoTime() - t) / 1_000_000).toInt()
        }.getOrNull()
    }

    suspend fun auto(servers: List<ServerConfig>): ServerConfig? = coroutineScope {
        servers.map { s -> async { s to ping(s) } }.awaitAll()
            .filter { it.second != null }.minByOrNull { it.second!! }?.first
    }

    fun random(servers: List<ServerConfig>) = servers.randomOrNull()
}
