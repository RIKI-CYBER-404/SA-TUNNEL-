package com.example.tunnelx.data
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject

/**
 * Remote update: host a JSON file (GitHub raw / your server):
 * { "version": 12, "groups": { "BANGLADESH": ["vless://..."], "SAUDI_ARABIA": [...], "MIDDLE_EAST": [...], "GLOBAL": [...] } }
 * Persist the result (DataStore/Room) and only replace when version increases.
 */
class ConfigUpdater(private val http: OkHttpClient = OkHttpClient()) {
    data class Result(val version: Int, val servers: List<ServerConfig>)

    suspend fun fetch(url: String): Result = withContext(Dispatchers.IO) {
        val body = http.newCall(Request.Builder().url(url).build()).execute().use { it.body!!.string() }
        val j = JSONObject(body); val groups = j.getJSONObject("groups"); val out = mutableListOf<ServerConfig>()
        groups.keys().forEach { key ->
            val region = runCatching { Region.valueOf(key) }.getOrDefault(Region.GLOBAL)
            val arr = groups.getJSONArray(key)
            for (i in 0 until arr.length()) ConfigParser.parse(arr.getString(i))?.let { out += it.copy(region = region) }
        }
        Result(j.optInt("version"), out)
    }
}
