package com.satunnel.app

import android.net.VpnService
import android.content.Intent
import android.net.Uri
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import com.satunnel.app.data.Profile
import com.satunnel.app.service.SATunnelVpnService
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Blue = Color(0xFF0757D8)
private val Teal = Color(0xFF236879)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val filter = IntentFilter(SATunnelVpnService.ACTION_STATE)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(stateReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        else { @Suppress("DEPRECATION") registerReceiver(stateReceiver, filter) }
        setContent { SATunnelApp() }
    }

    private val stateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val state = intent?.getStringExtra(SATunnelVpnService.EXTRA_STATE) ?: return
            getSharedPreferences(SATunnelVpnService.PREFS, MODE_PRIVATE).edit()
                .putString(SATunnelVpnService.KEY_STATE, state)
                .putBoolean(SATunnelVpnService.KEY_CONNECTED, state == "CONNECTED").apply()
            stateCallback?.invoke(state)
        }
    }
    private var stateCallback: ((String) -> Unit)? = null

    override fun onDestroy() {
        runCatching { unregisterReceiver(stateReceiver) }
        super.onDestroy()
    }

    private fun startSelectedProfile(profile: Profile) {
        val intent = Intent(this, SATunnelVpnService::class.java).setAction(SATunnelVpnService.ACTION_START)
            .putExtra(SATunnelVpnService.EXTRA_LINK, profile.shareLink)
            .putExtra(SATunnelVpnService.EXTRA_NAME, profile.name)
            .putExtra(SATunnelVpnService.EXTRA_PROTOCOL, profile.protocol)
            .putExtra(SATunnelVpnService.EXTRA_DNS, profile.dns)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        stateCallback?.invoke("CONNECTING")
    }

    @Composable private fun SATunnelApp() {
        var dark by remember { mutableStateOf(false) }
        val savedState = remember {
            getSharedPreferences(SATunnelVpnService.PREFS, MODE_PRIVATE)
                .getString(SATunnelVpnService.KEY_STATE, "DISCONNECTED") ?: "DISCONNECTED"
        }
        var connected by remember { mutableStateOf(savedState == "CONNECTED") }
        var status by remember { mutableStateOf(savedState) }
        var busy by remember { mutableStateOf(savedState == "CONNECTING" || savedState == "DISCONNECTING") }
        val context = this@MainActivity
        DisposableEffect(Unit) {
            stateCallback = { state ->
                status = state
                connected = state == "CONNECTED"
                busy = state == "CONNECTING" || state == "DISCONNECTING"
            }
            onDispose { stateCallback = null }
        }
        var selected by remember { mutableStateOf(Profile("Auto Select Server", "VLESS", region = "Random Server")) }
        var showProfiles by remember { mutableStateOf(false) }
        var drawer by remember { mutableStateOf(false) }
        var dialog by remember { mutableStateOf("") }
        var imported by remember { mutableStateOf("No profile imported") }
        val profiles = remember { mutableStateListOf(
            Profile("DNS GOOGLE", "DNS", "8.8.8.8", 53, "DNS GOOGLE"),
            Profile("Saudi Arabia STC FR NEW", "SSH", region = "STC"),
            Profile("KSA STC FR VIP Trojan", "TROJAN", region = "STC"),
            Profile("KSA STC FR VIP ALL AREA", "VLESS", region = "STC"),
            Profile("KSA STC FR VIP 2026", "VMESS", region = "STC"),
            Profile("Saudi Arabia Zain", "VLESS", region = "Zain"),
            Profile("Saudi Arabia Mobily", "VLESS", region = "Mobily")
        ) }
        LaunchedEffect(Unit) {
            val bundled = withContext(kotlinx.coroutines.Dispatchers.IO) {
                runCatching { assets.open("all.txt").bufferedReader().use { Profile.parseSubscription(it.readText(), 12000) } }.getOrDefault(emptyList())
            }
            if (bundled.isNotEmpty()) profiles.addAll(0, bundled)
        }
        val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            if (uri != null) try {
                contentResolver.openInputStream(uri)?.bufferedReader()?.use { reader ->
                    val text = reader.readText()
                    val parsed = Profile.parseSubscription(text)
                    val added = if (parsed.isNotEmpty()) parsed else listOf(Profile.fromJson(text))
                    profiles.addAll(0, added); selected = added.first()
                    imported = "Imported ${added.size} profile(s)"
                }
            } catch (e: Exception) { dialog = "Import failed: ${e.message}" }
        }
        val vpnPermission = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == RESULT_OK) startSelectedProfile(selected) else { status = "DISCONNECTED"; dialog = "VPN permission was denied." }
        }
        fun connectOrDisconnect() {
            if (connected || busy) {
                startService(Intent(context, SATunnelVpnService::class.java).setAction(SATunnelVpnService.ACTION_STOP))
                connected = false; busy = false; status = "DISCONNECTING"
            } else {
                if (selected.shareLink.isBlank()) { dialog = "Select an imported server URI first. Demo labels do not contain server credentials."; return }
                val permission = VpnService.prepare(context)
                if (permission != null) vpnPermission.launch(permission) else startSelectedProfile(selected)
            }
        }
        val drawerState = rememberDrawerState(DrawerValue.Closed)
        LaunchedEffect(drawer) { if (drawer) drawerState.open() else drawerState.close() }
        MaterialTheme(colorScheme = if (dark) darkColorScheme(primary = Blue) else lightColorScheme(primary = Blue)) {
            ModalNavigationDrawer(
                drawerState = drawerState,
                drawerContent = {
                    ModalDrawerSheet {
                        Text("SA TUNNEL", modifier = Modifier.padding(22.dp), color = Blue, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        NavigationDrawerItem(label = { Text("Dashboard") }, selected = true, onClick = { drawer = false }, icon = { Icon(Icons.Default.Home, null) })
                        NavigationDrawerItem(label = { Text("Enable Dark Theme") }, selected = dark, onClick = { dark = !dark }, icon = { Icon(Icons.Default.Palette, null) })
                        listOf("V2Ray Settings", "IP Hunt (not included)", "Custom DNS", "Online Update", "Offline Update", "Clipboard Update", "Logs", "Telegram", "Privacy policy").forEach { item ->
                            NavigationDrawerItem(label = { Text(item) }, selected = false, onClick = { drawer = false; dialog = when(item) {
                                "Offline Update" -> "Choose a .json profile using the import button on the dashboard."
                                "Custom DNS" -> "DNS is stored per profile. Use a trusted resolver such as 1.1.1.1 or 8.8.8.8."
                                "IP Hunt (not included)" -> "Subnet scanning for carrier proxy endpoints is not included. Add only servers you own or are authorized to use."
                                else -> "$item is a placeholder in this starter project."
                            } }, icon = { Icon(Icons.Default.Settings, null) })
                        }
                    }
                }
            ) {
                Scaffold(bottomBar = {
                    NavigationBar(containerColor = Blue, contentColor = Color.White) {
                        NavigationBarItem(selected = false, onClick = { dialog = "No update feed configured. Add your trusted HTTPS JSON endpoint in project settings." }, icon = { Icon(Icons.Default.CloudDownload, null) }, label = { Text("UPDATES") })
                        NavigationBarItem(selected = false, onClick = { dialog = "Connection logs will appear here after a real VPN engine is integrated." }, icon = { Icon(Icons.Default.ReceiptLong, null) }, label = { Text("Logs") })
                        NavigationBarItem(selected = false, onClick = { dialog = "Community link not configured." }, icon = { Icon(Icons.Default.Groups, null) }, label = { Text("Join Us") })
                        NavigationBarItem(selected = false, onClick = { dialog = "Use Android Back to leave SA TUNNEL." }, icon = { Icon(Icons.Default.ExitToApp, null) }, label = { Text("Exit") })
                    }
                }) { padding ->
                    Column(Modifier.fillMaxSize().padding(padding).background(MaterialTheme.colorScheme.background)) {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { drawer = true }) { Icon(Icons.Default.Menu, contentDescription = "Menu", tint = Blue) }
                            Text("1.0.0 Build 1", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(Modifier.weight(1f))
                            Text("SA TUNNEL", color = Blue, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.height(18.dp))
                        Box(Modifier.align(Alignment.CenterHorizontally).size(164.dp).shadow(8.dp, CircleShape).background(Color(0xFF06152C), CircleShape), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Default.Shield, null, tint = Color(0xFF00C8B4), modifier = Modifier.size(76.dp))
                                Text("SA", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Black)
                                Text("T U N N E L", color = Color.White, fontSize = 11.sp)
                            }
                        }
                        Spacer(Modifier.height(20.dp))
                        Row(Modifier.fillMaxWidth().padding(horizontal = 30.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("⇩  0 KB", fontSize = 14.sp); Text("0 KB  ⇧", fontSize = 14.sp)
                        }
                        val statusColor = when {
                            connected -> Color(0xFF00A86B)
                            busy -> Color(0xFFE09A18)
                            status.startsWith("ERROR") -> Color(0xFFD32F2F)
                            else -> Color(0xFFD32F4B)
                        }
                        Text(
                            status,
                            modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
                            textAlign = TextAlign.Center,
                            color = statusColor,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text("Config: ${selected.protocol}  |  ${selected.server}:${selected.port}", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                        Spacer(Modifier.height(30.dp))
                        OutlinedCard(Modifier.fillMaxWidth().padding(horizontal = 22.dp).clickable { dialog = "Location: ${selected.region}" }, border = BorderStroke(2.dp, Teal), shape = RoundedCornerShape(18.dp)) {
                            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.MyLocation, null, tint = Blue, modifier = Modifier.size(30.dp)); Spacer(Modifier.width(14.dp))
                                Column { Text("LOCATION", color = Blue, fontSize = 10.sp); Text(selected.name, fontWeight = FontWeight.Medium); Text(selected.region, fontSize = 12.sp, color = Color.Gray) }
                            }
                        }
                        Spacer(Modifier.height(20.dp))
                        OutlinedCard(Modifier.fillMaxWidth().padding(horizontal = 22.dp).clickable { showProfiles = true }, border = BorderStroke(2.dp, Teal), shape = RoundedCornerShape(18.dp)) {
                            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Security, null, tint = Color(0xFF5A168C), modifier = Modifier.size(34.dp)); Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) { Text("NETWORK", color = Blue, fontSize = 10.sp); Text(selected.name, fontWeight = FontWeight.Medium); Text("${selected.protocol} • ${selected.region}", fontSize = 12.sp, color = Color.Gray) }
                                Icon(Icons.Default.PlaylistAdd, null, tint = Blue)
                            }
                        }
                        Text(imported, modifier = Modifier.fillMaxWidth().padding(top = 7.dp), textAlign = TextAlign.Center, color = Color.Gray, fontSize = 11.sp)
                        Spacer(Modifier.height(38.dp))
                        val buttonColor by animateColorAsState(if (connected) Color(0xFFD32F2F) else Color(0xFF00B85A), label = "button")
                        Box(Modifier.align(Alignment.CenterHorizontally).size(174.dp).background(Color(0xFFB7D0FF), CircleShape).padding(9.dp).background(buttonColor, CircleShape).clickable {
                            connectOrDisconnect()
                        }, contentAlignment = Alignment.Center) {
                            Text(if (connected || busy) "STOP" else "START", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.height(16.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                            TextButton(onClick = { filePicker.launch(arrayOf("application/json", "text/*", "application/octet-stream")) }) { Icon(Icons.Default.FileOpen, null); Text(" Import JSON profile") }
                        }
                    }
                }
            }
            if (showProfiles) AlertDialog(onDismissRequest = { showProfiles = false }, title = { Text("Select network") }, text = {
                var query by remember { mutableStateOf("") }
                Column {
                    OutlinedTextField(value = query, onValueChange = { query = it }, label = { Text("Search network name") }, singleLine = true)
                    LazyColumn(Modifier.heightIn(max = 430.dp)) {
                        items(profiles.filter { it.name.contains(query, true) || it.region.contains(query, true) }) { p ->
                            ListItem(headlineContent = { Text(p.name) }, supportingContent = { Text("${p.protocol} • ${p.region}") }, trailingContent = { if (p == selected) Icon(Icons.Default.CheckCircle, null, tint = Color(0xFF00B86B)) }, modifier = Modifier.clickable { selected = p; showProfiles = false })
                        }
                    }
                }
            }, confirmButton = { TextButton(onClick = { showProfiles = false }) { Text("Close") } })
            if (dialog.isNotBlank()) AlertDialog(onDismissRequest = { dialog = "" }, title = { Text("SA TUNNEL") }, text = { Text(dialog) }, confirmButton = { TextButton(onClick = { dialog = "" }) { Text("OK") } })
        }
    }
}
