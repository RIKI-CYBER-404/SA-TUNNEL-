package com.satunnel.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.IBinder
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import com.satunnel.app.R
import com.satunnel.app.data.Profile
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class SATunnelVpnService : VpnService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var tun: ParcelFileDescriptor? = null
    private var engine: LibXrayEngine? = null

    override fun onBind(intent: Intent?): IBinder? = super.onBind(intent)

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { scope.launch { stopTunnel(); stopSelf(startId) }; return START_NOT_STICKY }
            ACTION_START -> {
                publishState("CONNECTING")
                val link = intent.getStringExtra(EXTRA_LINK).orEmpty()
                val name = intent.getStringExtra(EXTRA_NAME).orEmpty()
                val protocol = intent.getStringExtra(EXTRA_PROTOCOL).orEmpty()
                val dns = intent.getStringExtra(EXTRA_DNS) ?: "1.1.1.1"
                scope.launch { startTunnel(Profile(name, protocol, dns = dns, shareLink = link)) }
            }
        }
        return START_NOT_STICKY
    }

    private suspend fun startTunnel(profile: Profile) {
        stopTunnel()
        publishState("CONNECTING")
        startForeground(NOTIFICATION_ID, notification("Connecting…"))
        try {
            val builder = Builder().setSession("SA TUNNEL • ${profile.name}")
                .setMtu(1500).addAddress("10.88.0.1", 32)
                .addRoute("0.0.0.0", 0).addDnsServer(profile.dns.takeIf { it.matches(Regex("[0-9.]+")) } ?: "1.1.1.1")
            tun = builder.establish() ?: error("Android did not create the VPN interface")
            val fd = tun!!.fd
            engine = LibXrayEngine(this)
            engine!!.start(this, profile, fd).getOrThrow()
            publishState("CONNECTED")
            updateNotification("CONNECTED • ${profile.name}")
        } catch (t: Throwable) {
            runCatching { engine?.stop() }
            tun?.close(); tun = null; engine = null
            publishState("ERROR: ${t.message ?: t.javaClass.simpleName}")
            stopForeground(STOP_FOREGROUND_REMOVE); stopSelf()
        }
    }

    private suspend fun stopTunnel() {
        runCatching { engine?.stop()?.getOrThrow() }
        engine = null
        runCatching { tun?.close() }; tun = null
        publishState("DISCONNECTED")
        stopForeground(STOP_FOREGROUND_REMOVE)
    }

    /** Persist first, then broadcast so the UI can recover the real state after recreation. */
    private fun publishState(state: String) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .putString(KEY_STATE, state)
            .putBoolean(KEY_CONNECTED, state == "CONNECTED")
            .apply()
        sendBroadcast(Intent(ACTION_STATE).setPackage(packageName).putExtra(EXTRA_STATE, state))
    }

    private fun notification(text: String): Notification {
        val channel = "sa_tunnel_vpn"
        if (Build.VERSION.SDK_INT >= 26) getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(channel, "SA TUNNEL VPN", NotificationManager.IMPORTANCE_LOW))
        return NotificationCompat.Builder(this, channel).setSmallIcon(android.R.drawable.stat_sys_warning)
            .setContentTitle("SA TUNNEL").setContentText(text).setOngoing(true).build()
    }
    private fun updateNotification(text: String) { getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification(text)) }

    override fun onRevoke() {
        scope.launch { stopTunnel(); stopSelf() }
        super.onRevoke()
    }

    override fun onDestroy() { scope.cancel(); runCatching { tun?.close() }; super.onDestroy() }

    companion object {
        const val ACTION_START = "com.satunnel.START"
        const val ACTION_STOP = "com.satunnel.STOP"
        const val ACTION_STATE = "com.satunnel.STATE"
        const val EXTRA_LINK = "share_link"
        const val EXTRA_NAME = "profile_name"
        const val EXTRA_PROTOCOL = "protocol"
        const val EXTRA_DNS = "dns"
        const val EXTRA_STATE = "state"
        const val PREFS = "satunnel_runtime"
        const val KEY_CONNECTED = "connected"
        const val KEY_STATE = "connection_state"
        private const val NOTIFICATION_ID = 7341
    }
}
