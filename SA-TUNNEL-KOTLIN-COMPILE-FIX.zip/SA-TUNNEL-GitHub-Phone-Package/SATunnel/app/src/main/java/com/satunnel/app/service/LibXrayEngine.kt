package com.satunnel.app.service

import android.content.Context
import android.net.VpnService
import android.util.Log
import com.satunnel.app.data.Profile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.lang.reflect.Proxy

/** Reflection keeps compile-time coupling low; runtime requires the libXray AAR. */
class LibXrayEngine(private val vpn: VpnService) : TunnelEngine {
    private val coreClass by lazy { Class.forName("libXray.LibXray") }
    private var running = false

    private fun invoke(method: String, payload: JSONObject = JSONObject()): JSONObject {
        val request = JSONObject().put("apiVersion", 3).put("method", method).put("payload", payload).toString()
        val fn = coreClass.methods.firstOrNull { it.name.equals("invoke", true) && it.parameterTypes.contentEquals(arrayOf(String::class.java)) }
            ?: error("libXray Invoke(String) API not found. Check the AAR version.")
        val receiver = if (java.lang.reflect.Modifier.isStatic(fn.modifiers)) null else coreClass.getDeclaredConstructor().newInstance()
        val response = fn.invoke(receiver, request) as? String ?: error("libXray returned an empty response")
        val json = JSONObject(response)
        if (!json.optBoolean("success")) error(json.optString("error", "Xray core operation failed"))
        return json.optJSONObject("data") ?: JSONObject()
    }

    private fun registerProtectController(dns: String) {
        val controller = coreClass.methods.firstOrNull { it.name.equals("registerDialerController", true) } ?: return
        val iface = controller.parameterTypes.first()
        val proxy = Proxy.newProxyInstance(iface.classLoader, arrayOf(iface)) { _, method, args ->
            if (method.name.equals("protectFd", true)) vpn.protect((args?.firstOrNull() as Number).toInt()) else false
        }
        controller.invoke(null, proxy)
        coreClass.methods.firstOrNull { it.name.equals("registerListenerController", true) }?.invoke(null, proxy)
        coreClass.methods.firstOrNull { it.name.equals("setDNS", true) }?.let { m ->
            if (m.parameterTypes.size == 2) m.invoke(null, proxy, "${dns}:53")
        }
    }

    override suspend fun start(context: Context, profile: Profile, tunFd: Int): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            require(profile.protocol in setOf("VLESS", "VMESS", "TROJAN", "HYSTERIA2")) {
                "${profile.protocol} is not supported by the bundled Xray engine. Use VLESS, VMess, Trojan or a supported Hysteria2 link."
            }
            require(profile.shareLink.isNotBlank()) { "This profile has no share URI. Import a vless://, vmess://, trojan:// or hysteria2:// link." }
            registerProtectController(profile.dns)
            val parsed = invoke("convertShareLinksToXrayJson", JSONObject().put("text", profile.shareLink))
            val outbounds = parsed.optJSONArray("outbounds") ?: JSONArray()
            require(outbounds.length() > 0) { "The selected share link could not be parsed by Xray." }
            val config = JSONObject()
                .put("log", JSONObject().put("loglevel", "warning"))
                .put("env", JSONObject().put("xray.tun.fd", tunFd.toString()))
                .put("inbounds", JSONArray().put(JSONObject()
                    .put("tag", "satunnel-tun")
                    .put("protocol", "tun")
                    .put("port", 0)
                    .put("settings", JSONObject().put("name", "satun0").put("mtu", 1500))))
                .put("outbounds", outbounds)
            val hasDirect = (0 until outbounds.length()).any { outbounds.optJSONObject(it)?.optString("tag") == "direct" }
            if (!hasDirect) outbounds.put(JSONObject().put("tag", "direct").put("protocol", "freedom"))
            val defaultTag = outbounds.optJSONObject(0)?.optString("tag").orEmpty().ifBlank { "proxy" }
            config.put("routing", JSONObject().put("domainStrategy", "IPIfNonMatch").put("rules", JSONArray()
                .put(JSONObject().put("type", "field").put("ip", JSONArray().put("geoip:private")).put("outboundTag", "direct"))))
            invoke("runXray", JSONObject().put("xrayJson", config.toString()))
            running = true
            Log.i("SATunnel", "Xray core start request accepted for $defaultTag")
            Unit
        }
    }

    override suspend fun stop(): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            if (running) invoke("stopXray")
            coreClass.methods.firstOrNull { it.name.equals("resetDNS", true) }?.invoke(null)
            running = false
        }
    }
}
