package com.satunnel.app.data

import android.net.Uri
import java.net.URLDecoder
import org.json.JSONObject

data class Profile(
    val name: String,
    val protocol: String,
    val server: String = "",
    val port: Int = 0,
    val region: String = "Unknown",
    val dns: String = "1.1.1.1",
    val shareLink: String = ""
) {
    companion object {
        private val schemes = mapOf(
            "vless" to "VLESS", "vmess" to "VMESS", "trojan" to "TROJAN",
            "hysteria" to "HYSTERIA", "hysteria2" to "HYSTERIA2", "hy2" to "HYSTERIA2",
            "ssh" to "SSH"
        )

        fun fromShareLink(line: String): Profile? {
            val raw = line.trim().replace("&amp;", "&")
            val scheme = raw.substringBefore(":", "").lowercase()
            val proto = schemes[scheme] ?: return null
            if (scheme == "vmess" && raw.startsWith("vmess://")) {
                // Keep the original link for the native parser; legacy VMess QR links may be rejected by the core.
                val encoded = raw.removePrefix("vmess://").substringBefore('#')
                val decoded = runCatching { String(android.util.Base64.decode(encoded, android.util.Base64.DEFAULT)) }.getOrNull()
                if (decoded != null) {
                    val j = runCatching { JSONObject(decoded) }.getOrNull()
                    if (j != null) return Profile(j.optString("ps", "VMess server"), proto, j.optString("add"), j.optInt("port"), "Imported", shareLink = raw)
                }
            }
            val uri = runCatching { Uri.parse(raw) }.getOrNull() ?: return null
            val host = uri.host.orEmpty()
            val port = uri.port.coerceAtLeast(0)
            val fragment = runCatching { URLDecoder.decode(uri.fragment.orEmpty(), "UTF-8") }.getOrNull().orEmpty()
            val label = fragment.takeIf { it.isNotBlank() } ?: "$proto • ${host.ifBlank { "Imported server" }}"
            return Profile(label, proto, host, port, "Imported", shareLink = raw)
        }

        fun fromJson(text: String): Profile {
            val j = JSONObject(text)
            val link = j.optString("url", j.optString("shareLink", ""))
            if (link.isNotBlank()) return fromShareLink(link) ?: error("Unsupported share link")
            val port = j.optInt("port", 0)
            require(port in 1..65535) { "Port must be between 1 and 65535" }
            val protocol = j.optString("protocol", "VLESS").uppercase()
            require(protocol in setOf("SSH", "VMESS", "VLESS", "TROJAN", "HYSTERIA", "HYSTERIA2")) { "Unsupported protocol" }
            return Profile(j.optString("name", "Imported profile"), protocol, j.optString("server", ""), port,
                j.optString("region", "Unknown"), j.optString("dns", "1.1.1.1"), j.optString("shareLink", ""))
        }

        fun parseSubscription(text: String, limit: Int = 12000): List<Profile> {
            val seen = HashSet<String>()
            val result = ArrayList<Profile>()
            for (line in text.lineSequence()) {
                val value = line.trim()
                if (!value.contains("://") || value.startsWith("#") || !seen.add(value)) continue
                val profile = fromShareLink(value) ?: continue
                result.add(profile)
                if (result.size >= limit) break
            }
            return result
        }
    }
}
