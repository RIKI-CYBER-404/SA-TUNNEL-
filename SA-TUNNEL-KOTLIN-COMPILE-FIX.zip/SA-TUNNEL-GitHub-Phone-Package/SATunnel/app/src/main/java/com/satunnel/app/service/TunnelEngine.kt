package com.satunnel.app.service

import android.content.Context
import com.satunnel.app.data.Profile

/** Engine boundary. Xray supports VLESS, VMess and Trojan profiles in this build.
 * SSH requires a separate SSH client engine and is rejected instead of fake-connecting.
 */
interface TunnelEngine {
    suspend fun start(context: Context, profile: Profile, tunFd: Int): Result<Unit>
    suspend fun stop(): Result<Unit>
}
