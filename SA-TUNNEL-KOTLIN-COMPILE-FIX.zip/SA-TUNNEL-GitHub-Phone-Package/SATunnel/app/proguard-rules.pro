# Keep JNI entry points when a native VPN engine is added.
-keepclasseswithmembernames class * { native <methods>; }
-keep class com.satunnel.app.engine.** { *; }

# libXray uses gomobile-generated Java entry points discovered by reflection.
-keep class libXray.** { *; }
-keep interface libXray.** { *; }
