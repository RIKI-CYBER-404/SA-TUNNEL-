# Third-party notices

- XTLS/libXray upstream source: https://github.com/XTLS/libXray — MIT License. The build workflow pins v26.10.31.
- Xray-core is distributed under its own upstream license. See https://github.com/XTLS/Xray-core and preserve its license/notice files when redistributing.
- AndroidX, Jetpack Compose, Kotlin, and Gradle dependencies retain their respective upstream licenses.

The native AAR is built from upstream source by the included workflow; no prebuilt native binary is bundled in this ZIP.
