# SA TUNNEL — Android VPN client (Xray engine integration)

This project now includes an Android `VpnService` lifecycle and an XTLS/libXray API-v3 adapter. The engine creates an Android TUN interface, registers socket-protection callbacks, converts a share URI to Xray JSON, injects `xray.tun.fd`, starts Xray, and stops it on disconnect. The native AAR is built from the official XTLS/libXray source pinned to v26.10.31 by the included GitHub Actions workflow; it is not bundled in this source ZIP.

## Protocol coverage in this build

- **VLESS, VMess AEAD, Trojan:** supported by the Xray share-link parser/core when the imported URI is valid and the server is reachable.
- **Hysteria2 (`hysteria2://`, `hy2://`):** the pinned upstream libXray parser/core may accept supported URI variants; runtime compatibility depends on the exact protocol features and server settings. Verify with a known-good server.
- **SSH and legacy Hysteria v1:** not implemented by this Xray adapter. They are rejected with a visible error; they must not display CONNECTED. A separate, compatible engine is required for those protocols.
- Legacy VMess QR/base64 links may not be accepted by current libXray (the upstream parser documents VMessAEAD URI support, not legacy QR-code links).

Do not add a second Go-based core (for example, sing-box) into the same Android process without building a single combined Go runtime. The libXray upstream explicitly warns that multiple independent Go runtimes in one process can fail to link or crash.

## Build APK

### Android Studio

1. Extract the ZIP and open the `SATunnel` directory.
2. Use JDK 17 and Android SDK Platform 35.
3. Build the native engine first with `./build_core.sh` (requires Go 1.25+, Android SDK/NDK and Python 3); this creates `app/libs/libXray.aar`.
4. Sync Gradle, then Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Install `app/build/outputs/apk/debug/app-debug.apk`.

### GitHub Actions from an Android phone

1. Upload both the `SATunnel` folder and the root `.github` folder from the extracted ZIP to a GitHub repository.
2. Open **Actions** and run **Build SA TUNNEL APK** (or push a commit).
3. Download the `SA-TUNNEL-debug-apk` artifact after the workflow succeeds.

## Import profiles

- The bundled `app/src/main/assets/all.txt` contains the supplied 75,809-line source list. On first launch the app loads up to 12,000 parseable share links into the searchable selector.
- Use **Import Config / Subscription** to import a text subscription, URI list, or JSON profile.
- Select a profile, press START, approve Android's VPN permission dialog, and watch the status. A successful core start is reported as CONNECTED; core errors are reported as ERROR.
- Public/free configs may be expired, overloaded, malicious, or not authorized for use. The app does not certify or guarantee any server. Only use endpoints and credentials you are authorized to use.

## Important implementation notes

- Android `VpnService` is the system TUN permission boundary. The Xray TUN inbound receives the established interface file descriptor via `env.xray.tun.fd`.
- Outbound sockets are protected with `VpnService.protect()` to prevent routing loops.
- The app currently routes IPv4 default traffic. IPv6 full-tunnel routing, traffic byte counters, auto-reconnect, subscription signature verification, per-app routing, and hotspot/tethering support still need device-level engineering and testing.
- The Xray core start response is not a guarantee that a remote server is reachable. Test on a physical device and inspect Android logs if traffic does not pass.
- Never disable TLS certificate verification to make an unknown config connect. This app does not intentionally implement carrier payload/SNI tricks or scan carrier subnets.

## Dependencies and licensing

- AndroidX / Jetpack Compose dependencies are declared in `app/build.gradle.kts`.
- The GitHub Actions workflow checks out official `XTLS/libXray` tag `v26.10.31` and builds `libXray.aar` from source.
- Upstream libXray source: https://github.com/XTLS/libXray (MIT license). Xray-core has its own license and notices; retain all third-party notices when redistributing.

## Status

Source integration is present, but this environment does not have Android SDK/Gradle available, so an APK build and real-device tunnel test have **not** been performed here. The provided GitHub Actions workflow is the next build verification step.
