#!/usr/bin/env bash
set -euo pipefail
# Linux/macOS: requires JDK 17, Go 1.25+, Android SDK/NDK, Python 3 and Git.
ROOT="$(cd "$(dirname "$0")" && pwd)"
WORK="${ROOT}/.core-build/libXray"
mkdir -p "${ROOT}/app/libs" "$(dirname "$WORK")"
if [[ ! -d "$WORK/.git" ]]; then
  git clone --depth 1 --branch v26.10.31 https://github.com/XTLS/libXray.git "$WORK"
fi
export PATH="$(go env GOPATH)/bin:$PATH"
go install golang.org/x/mobile/cmd/gomobile@latest
gomobile init
(cd "$WORK" && python3 build/main.py android)
cp "$WORK/libXray.aar" "$ROOT/app/libs/libXray.aar"
echo "Built app/libs/libXray.aar"
