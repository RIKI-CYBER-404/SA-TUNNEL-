package com.satunnel.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.IBinder
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import com.satunnel.app.R
import com.satunnel.app.data.Profile
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class SATunnelVpnService : VpnService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var tun: ParcelFileDescriptor? = null
    private var engine: LibXrayEngine? = null
    private val tunnelMutex = Mutex()

    override fun onBind(intent: Intent?): IBinder? = super.onBind(intent)

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                scope.launch {
                    tunnelMutex.withLock { stopTunnelLocked() }
                    stopSelf(startId)
                }
                return START_NOT_STICKY
            }
            ACTION_START -> {
                // Promote immediately; Android 8+ requires foreground promotion promptly.
                startForeground(NOTIFICATION_ID, notification("Connecting…"))
                val link = intent.getStringExtra(EXTRA_LINK).orEmpty()
                val name = intent.getStringExtra(EXTRA_NAME).orEmpty()
                val protocol = intent.getStringExtra(EXTRA_PROTOCOL).orEmpty()
                val dns = intent.getStringExtra(EXTRA_DNS) ?: "1.1.1.1"
                scope.launch {
                    tunnelMutex.withLock {
                        startTunnelLocked(Profile(name, protocol, dns = dns, shareLink = link))
                    }
                }
            }
        }
        return START_NOT_STICKY
    }

    private suspend fun startTunnelLocked(profile: Profile) {
        stopTunnelLocked(publishDisconnected = false)
        startForeground(NOTIFICATION_ID, notification("Connecting…"))
        publishState("CONNECTING")
        try {
            require(profile.shareLink.isNotBlank()) { "No server URI imported. Select a real profile before connecting." }
            require(profile.protocol in setOf("VLESS", "VMESS", "TROJAN", "HYSTERIA2")) {
                if (profile.protocol == "SSH") "SSH tunnel engine is not included in this build. SSH cannot connect yet."
                else "Unsupported protocol: ${profile.protocol}"
            }
            val dnsServer = profile.dns.takeIf { isValidIpv4(it) } ?: "1.1.1.1"
            val builder = Builder().setSession("SA TUNNEL • ${profile.name}")
                .setMtu(1500)
                .addAddress("10.88.0.1", 32)
                .addAddress("fd88:88::1", 128)
                .addRoute("0.0.0.0", 0)
                .addRoute("::", 0)
                .addDnsServer(dnsServer)
            tun = builder.establish() ?: error("Android did not create the VPN interface")
            val fd = tun!!.fd
            engine = LibXrayEngine(this)
            engine!!.start(this, profile, fd).getOrThrow()
            publishState("CONNECTED")
            updateNotification("CONNECTED • ${profile.name}")
        } catch (t: Throwable) {
            runCatching { engine?.stop()?.getOrThrow() }
            engine = null
            runCatching { tun?.close() }
            tun = null
            publishState("ERROR: ${t.message ?: t.javaClass.simpleName}")
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private suspend fun stopTunnelLocked(publishDisconnected: Boolean = true) {
        runCatching { engine?.stop()?.getOrThrow() }
        engine = null
        runCatching { tun?.close() }
        tun = null
        if (publishDisconnected) publishState("DISCONNECTED")
        stopForeground(STOP_FOREGROUND_REMOVE)
    }

    private fun isValidIpv4(value: String): Boolean {
        val parts = value.split('.')
        return parts.size == 4 && parts.all { part ->
            part.isNotEmpty() && part.length <= 3 && part.all(Char::isDigit) &&
                part.toIntOrNull()?.let { it in 0..255 } == true
        }
    }

    /** Persist first, then broadcast so the UI can recover the real state after recreation. */
    private fun publishState(state: String) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .putString(KEY_STATE, state)
            .putBoolean(KEY_CONNECTED, state == "CONNECTED")
            .apply()
        sendBroadcast(Intent(ACTION_STATE).setPackage(packageName).putExtra(EXTRA_STATE, state))
    }

    private fun notification(text: String): Notification {
        val channel = "sa_tunnel_vpn"
        if (Build.VERSION.SDK_INT >= 26) getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(channel, "SA TUNNEL VPN", NotificationManager.IMPORTANCE_LOW))
        return NotificationCompat.Builder(this, channel).setSmallIcon(android.R.drawable.stat_sys_warning)
            .setContentTitle("SA TUNNEL").setContentText(text).setOngoing(true).build()
    }
    private fun updateNotification(text: String) { getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification(text)) }

    override fun onRevoke() {
        scope.launch {
            tunnelMutex.withLock { stopTunnelLocked() }
            stopSelf()
        }
        super.onRevoke()
    }

    override fun onDestroy() {
        // Stop the native core before releasing its TUN descriptor.
        runCatching { runBlocking { tunnelMutex.withLock { stopTunnelLocked() } } }
        scope.cancel()
        runCatching { tun?.close() }
        tun = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.satunnel.START"
        const val ACTION_STOP = "com.satunnel.STOP"
        const val ACTION_STATE = "com.satunnel.STATE"
        const val EXTRA_LINK = "share_link"
        const val EXTRA_NAME = "profile_name"
        const val EXTRA_PROTOCOL = "protocol"
        const val EXTRA_DNS = "dns"
        const val EXTRA_STATE = "state"
        const val PREFS = "satunnel_runtime"
        const val KEY_CONNECTED = "connected"
        const val KEY_STATE = "connection_state"
        private const val NOTIFICATION_ID = 7341
    }
}
