package com.satunnel.app.data

import android.net.Uri
import java.net.URLDecoder
import org.json.JSONObject
import org.json.JSONArray

data class Profile(
    val name: String,
    val protocol: String,
    val server: String = "",
    val port: Int = 0,
    val region: String = "Unknown",
    val dns: String = "1.1.1.1",
    val shareLink: String = ""
) {
    companion object {
        private val schemes = mapOf(
            "vless" to "VLESS", "vmess" to "VMESS", "trojan" to "TROJAN",
            "hysteria2" to "HYSTERIA2", "hy2" to "HYSTERIA2",
            "ssh" to "SSH"
        )

        fun fromShareLink(line: String): Profile? {
            val raw = line.trim().replace("&amp;", "&")
            val scheme = raw.substringBefore(":", "").lowercase()
            val proto = schemes[scheme] ?: return null
            // libXray accepts VMess AEAD share links, not legacy VMess QR-code Base64(JSON) links.
            if (scheme == "vmess" && raw.startsWith("vmess://")) {
                val payload = raw.removePrefix("vmess://").substringBefore('#')
                val decoded = runCatching {
                    String(android.util.Base64.decode(payload, android.util.Base64.DEFAULT or android.util.Base64.URL_SAFE), Charsets.UTF_8)
                }.recoverCatching {
                    String(android.util.Base64.decode(payload, android.util.Base64.DEFAULT), Charsets.UTF_8)
                }.getOrNull()
                if (decoded?.trimStart()?.startsWith("{") == true) return null
            }
            val uri = runCatching { Uri.parse(raw) }.getOrNull() ?: return null
            val host = uri.host.orEmpty()
            val port = uri.port.coerceAtLeast(0)
            val fragment = runCatching { URLDecoder.decode(uri.fragment.orEmpty(), "UTF-8") }.getOrNull().orEmpty()
            val label = fragment.takeIf { it.isNotBlank() } ?: "$proto • ${host.ifBlank { "Imported server" }}"
            return Profile(label, proto, host, port, "Imported", shareLink = raw)
        }

        fun fromJson(text: String): Profile {
            val j = JSONObject(text)
            val outbounds = j.optJSONArray("outbounds")
            if (outbounds != null && outbounds.length() > 0) {
                return profilesFromXrayJson(j).firstOrNull()
                    ?: error("Xray JSON contains no supported VLESS, VMess, Trojan or Hysteria2 outbound")
            }
            val link = j.optString("url").ifBlank { j.optString("shareLink") }
            if (link.isNotBlank()) return fromShareLink(link) ?: error("Unsupported share link. Use a VLESS, VMess AEAD, Trojan or Hysteria2 URI.")
            error("This JSON has no usable server URI. Import a share link or an Xray JSON file with an outbounds array.")
        }

        private fun profilesFromXrayJson(root: JSONObject): List<Profile> {
            val source = root.optJSONArray("outbounds") ?: return emptyList()
            val result = ArrayList<Profile>()
            for (index in 0 until source.length()) {
                val outbound = source.optJSONObject(index) ?: continue
                val rawProtocol = outbound.optString("protocol").lowercase()
                val protocol = when (rawProtocol) {
                    "vless" -> "VLESS"
                    "vmess" -> "VMESS"
                    "trojan" -> "TROJAN"
                    "hysteria" -> "HYSTERIA2"
                    else -> continue
                }
                val nodeOnly = JSONObject().put("outbounds", JSONArray().put(outbound))
                val settings = outbound.optJSONObject("settings")
                val server = settings?.optJSONArray("vnext")?.optJSONObject(0)?.optString("address")
                    ?: settings?.optJSONArray("servers")?.optJSONObject(0)?.optString("address")
                    ?: ""
                val port = settings?.optJSONArray("vnext")?.optJSONObject(0)?.optInt("port")
                    ?: settings?.optJSONArray("servers")?.optJSONObject(0)?.optInt("port")
                    ?: 0
                val name = outbound.optString("tag").ifBlank { "$protocol ${index + 1}" }
                result.add(Profile(name, protocol, server, port, "Imported JSON", shareLink = nodeOnly.toString()))
            }
            return result
        }

        fun parseSubscription(text: String, limit: Int = 12000): List<Profile> {
            val trimmed = text.trim()
            if (trimmed.startsWith("{")) {
                val xrayProfiles = runCatching { profilesFromXrayJson(JSONObject(trimmed)) }.getOrDefault(emptyList())
                if (xrayProfiles.isNotEmpty()) return xrayProfiles.take(limit)
            }
            if (trimmed.startsWith("[")) {
                val jsonProfiles = runCatching {
                    val array = JSONArray(trimmed)
                    (0 until array.length()).mapNotNull { index ->
                        runCatching { fromJson(array.getJSONObject(index).toString()) }.getOrNull()
                    }
                }.getOrDefault(emptyList())
                if (jsonProfiles.isNotEmpty()) return jsonProfiles.take(limit)
            }
            val seen = HashSet<String>()
            val result = ArrayList<Profile>()
            for (line in text.lineSequence()) {
                val value = line.trim()
                if (!value.contains("://") || value.startsWith("#") || !seen.add(value)) continue
                val profile = fromShareLink(value) ?: continue
                result.add(profile)
                if (result.size >= limit) break
            }
            // Many VPN subscriptions are delivered as one Base64-encoded text document.
            if (result.isEmpty() && !text.contains("://")) {
                val decoded = runCatching {
                    String(android.util.Base64.decode(text.trim(), android.util.Base64.DEFAULT or android.util.Base64.URL_SAFE), Charsets.UTF_8)
                }.getOrNull()
                if (!decoded.isNullOrBlank() && decoded != text && decoded.contains("://")) {
                    return parseSubscription(decoded, limit)
                }
            }
            return result
        }
    }
}
