package com.satunnel.app.service

import android.content.Context
import android.net.VpnService
import android.util.Log
import com.satunnel.app.data.Profile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.lang.reflect.Proxy

/** Reflection keeps compile-time coupling low; runtime requires the libXray AAR. */
class LibXrayEngine(private val vpn: VpnService) : TunnelEngine {
    private val coreClass by lazy { Class.forName("libXray.LibXray") }
    private var running = false

    private fun invoke(method: String, payload: JSONObject = JSONObject()): JSONObject {
        val request = JSONObject().put("apiVersion", 3).put("method", method).put("payload", payload).toString()
        val fn = coreClass.methods.firstOrNull { it.name.equals("invoke", true) && it.parameterTypes.contentEquals(arrayOf(String::class.java)) }
            ?: error("libXray Invoke(String) API not found. Check the AAR version.")
        val receiver = if (java.lang.reflect.Modifier.isStatic(fn.modifiers)) null else coreClass.getDeclaredConstructor().newInstance()
        val response = fn.invoke(receiver, request) as? String ?: error("libXray returned an empty response")
        val json = JSONObject(response)
        if (!json.optBoolean("success")) error(json.optString("error", "Xray core operation failed"))
        return json.optJSONObject("data") ?: JSONObject()
    }

    private var dnsConfigured = false

    private fun registerProtectController(dns: String) {
        val dialerMethod = coreClass.methods.firstOrNull {
            it.name.equals("registerDialerController", true) && it.parameterTypes.size == 1
        } ?: error("libXray Android RegisterDialerController API is missing")
        val controllerType = dialerMethod.parameterTypes[0]
        val controller = Proxy.newProxyInstance(controllerType.classLoader, arrayOf(controllerType)) { proxy, method, args ->
            when (method.name.lowercase()) {
                "protectfd" -> {
                    val fd = (args?.firstOrNull() as? Number)?.toInt() ?: return@newProxyInstance false
                    vpn.protect(fd)
                }
                "tostring" -> "SATunnelProtectController"
                "hashcode" -> System.identityHashCode(proxy)
                "equals" -> proxy === args?.firstOrNull()
                else -> false
            }
        }
        dialerMethod.invoke(null, controller)

        // The listener callback uses the same gomobile interface contract.
        coreClass.methods.firstOrNull {
            it.name.equals("registerListenerController", true) && it.parameterTypes.size == 1
        }?.invoke(null, controller)

        val setDns = coreClass.methods.firstOrNull {
            it.name.equals("setDNS", true) && it.parameterTypes.size == 2
        } ?: error("libXray Android SetDNS API is missing")
        setDns.invoke(null, controller, "${dns}:53")
        dnsConfigured = true
    }

    override suspend fun start(context: Context, profile: Profile, tunFd: Int): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            require(profile.protocol != "SSH") {
                "SSH profile detected. SSH tunneling is not implemented in this build; import a VLESS, VMess, Trojan or supported Hysteria2 profile instead."
            }
            require(profile.protocol in setOf("VLESS", "VMESS", "TROJAN", "HYSTERIA2")) {
                "${profile.protocol} is not supported by this Xray build. Supported share links: VLESS, VMess, Trojan and supported Hysteria2."
            }
            require(tunFd > 0) { "Android VPN interface file descriptor is invalid." }
            require(profile.shareLink.isNotBlank()) { "This profile has no share URI. Import a vless://, vmess://, trojan:// or hysteria2:// link." }
            registerProtectController(profile.dns)
            val parsed = invoke("convertShareLinksToXrayJson", JSONObject().put("text", profile.shareLink))
            val outbounds = parsed.optJSONArray("outbounds") ?: JSONArray()
            require(outbounds.length() > 0) { "The selected share link could not be parsed by Xray." }
            val config = JSONObject()
                .put("log", JSONObject().put("loglevel", "warning"))
                .put("env", JSONObject().put("xray.tun.fd", tunFd.toString()))
                .put("inbounds", JSONArray().put(JSONObject()
                    .put("tag", "satunnel-tun")
                    .put("protocol", "tun")
                    .put("settings", JSONObject().put("name", "satun0").put("mtu", 1500))))
                .put("outbounds", outbounds)
            val hasDirect = (0 until outbounds.length()).any { outbounds.optJSONObject(it)?.optString("tag") == "direct" }
            if (!hasDirect) outbounds.put(JSONObject().put("tag", "direct").put("protocol", "freedom"))
            val defaultTag = outbounds.optJSONObject(0)?.optString("tag").orEmpty().ifBlank { "proxy" }
            // Do not reference geoip:private here: geoip.dat may not be packaged by the core build,
            // which makes Xray reject the entire config before starting. Keep routing minimal.
            invoke("runXray", JSONObject().put("xrayJson", config.toString()))
            running = true
            Log.i("SATunnel", "Xray core start request accepted for $defaultTag")
            Unit
        }
    }

    override suspend fun stop(): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            try {
                if (running) invoke("stopXray")
            } finally {
                if (dnsConfigured) {
                    coreClass.methods.firstOrNull { it.name.equals("resetDNS", true) }?.invoke(null)
                    dnsConfigured = false
                }
                running = false
            }
        }
    }
}
