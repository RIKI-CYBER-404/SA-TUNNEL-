SA TUNNEL does not bundle public VPN credentials or demo servers.
Import only server profiles/subscriptions that you own or are authorized to use.
