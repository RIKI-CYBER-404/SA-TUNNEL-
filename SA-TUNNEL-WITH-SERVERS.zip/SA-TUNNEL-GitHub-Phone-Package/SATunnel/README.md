# SA TUNNEL — Android VPN client source

Android/Kotlin + Jetpack Compose app with Android `VpnService` and the official XTLS/libXray Android AAR built by CI.

## Protocol support in this source
- **VLESS / VMess AEAD / Trojan:** parsed by libXray and passed to Xray-core. Legacy VMess QR-code Base64(JSON) links are not accepted by this libXray parser.
- **Hysteria2:** supported by the pinned libXray release for supported `hysteria2://` and `hy2://` URI variants. TLS is mandatory; insecure TLS options such as `insecure=true` / `allowInsecure=true` are rejected by libXray.
- **SSH:** not implemented as a full-device VPN. SSH profiles are not connectable. A real implementation needs an SSH transport, authentication, a SOCKS/local forwarding layer, and a TUN-to-SOCKS bridge/native packet engine. The app rejects SSH instead of pretending to connect.
- **Hysteria v1:** not supported by this adapter.

No public/demo server credentials are bundled. Import only server profiles/subscriptions you own or are authorized to use.

## Import
Use **Import JSON profile** to choose a text URI subscription, Base64-wrapped URI subscription, an Xray JSON file with an `outbounds` array, or a single JSON object containing a share URI in `url` / `shareLink`. JSON outbounds are split into selectable profiles. Supported URI schemes include `vless://`, VMess AEAD `vmess://`, `trojan://`, `hysteria2://` and `hy2://`.

## VPN behavior
The app creates an Android `VpnService` TUN interface, passes its file descriptor to Xray using the documented `xray.tun.fd` environment value, registers Android socket protection, and configures the selected DNS resolver before starting Xray. IPv4 and IPv6 default routes are requested from Android. A CONNECTED state means the local Xray engine and VPN interface started; it does not guarantee the remote server is reachable or that every app's traffic is passing.

## Build from Android using GitHub Actions
1. Extract the source ZIP.
2. Upload the **contents** of `SA-TUNNEL-GitHub-Phone-Package` to the root of a GitHub repository. The repository root must contain both `SATunnel/` and `.github/workflows/android.yml`.
3. Open **Actions** and run **Build SA TUNNEL APK** (or push a commit).
4. Download artifact **SA-TUNNEL-debug-apk** after the workflow succeeds.

The workflow checks out the pinned official XTLS/libXray release, builds its Android AAR, then runs Gradle `:app:assembleDebug`. No APK is included in this ZIP.

## Verification limits and remaining work
This environment does not contain the Android SDK/NDK or Gradle build environment, so a full Android build and real-device VPN test could not be run here. Run GitHub Actions before installing, then test with a valid server you control. SSH, traffic counters, auto-reconnect, per-app routing, tethering, and persistent encrypted profile storage are not implemented. Do not use unknown server credentials or disable TLS verification.
