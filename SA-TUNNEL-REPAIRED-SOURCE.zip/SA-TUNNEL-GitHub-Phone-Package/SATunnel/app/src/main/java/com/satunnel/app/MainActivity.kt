package com.satunnel.app

import android.net.VpnService
import android.content.Intent
import android.net.Uri
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.Image
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import com.satunnel.app.data.Profile
import com.satunnel.app.service.SATunnelVpnService
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Blue = Color(0xFF0757D8)
private val Teal = Color(0xFF236879)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val filter = IntentFilter(SATunnelVpnService.ACTION_STATE)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(stateReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        else { @Suppress("DEPRECATION") registerReceiver(stateReceiver, filter) }
        setContent { SATunnelApp() }
    }

    private val stateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val state = intent?.getStringExtra(SATunnelVpnService.EXTRA_STATE) ?: return
            getSharedPreferences(SATunnelVpnService.PREFS, MODE_PRIVATE).edit()
                .putString(SATunnelVpnService.KEY_STATE, state)
                .putBoolean(SATunnelVpnService.KEY_CONNECTED, state == "CONNECTED").apply()
            stateCallback?.invoke(state)
        }
    }
    private var stateCallback: ((String) -> Unit)? = null

    override fun onDestroy() {
        runCatching { unregisterReceiver(stateReceiver) }
        super.onDestroy()
    }

    private fun startSelectedProfile(profile: Profile) {
        val intent = Intent(this, SATunnelVpnService::class.java).setAction(SATunnelVpnService.ACTION_START)
            .putExtra(SATunnelVpnService.EXTRA_LINK, profile.shareLink)
            .putExtra(SATunnelVpnService.EXTRA_NAME, profile.name)
            .putExtra(SATunnelVpnService.EXTRA_PROTOCOL, profile.protocol)
            .putExtra(SATunnelVpnService.EXTRA_DNS, profile.dns)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        stateCallback?.invoke("CONNECTING")
    }

    @Composable private fun SATunnelApp() {
        var dark by remember { mutableStateOf(false) }
        val savedState = remember {
            getSharedPreferences(SATunnelVpnService.PREFS, MODE_PRIVATE)
                .getString(SATunnelVpnService.KEY_STATE, "DISCONNECTED") ?: "DISCONNECTED"
        }
        var connected by remember { mutableStateOf(savedState == "CONNECTED") }
        var status by remember { mutableStateOf(savedState) }
        var busy by remember { mutableStateOf(savedState == "CONNECTING" || savedState == "DISCONNECTING") }
        val context = this@MainActivity
        DisposableEffect(Unit) {
            stateCallback = { state ->
                status = state
                connected = state == "CONNECTED"
                busy = state == "CONNECTING" || state == "DISCONNECTING"
            }
            onDispose { stateCallback = null }
        }
        var selected by remember { mutableStateOf(Profile("Import a server profile", "VLESS", region = "Not configured")) }
        var showProfiles by remember { mutableStateOf(false) }
        var drawer by remember { mutableStateOf(false) }
        var dialog by remember { mutableStateOf("") }
        var imported by remember { mutableStateOf("No profile imported") }
        // Only show profiles that contain a real share URI; decorative/demo labels are not servers.
        val profiles = remember { mutableStateListOf<Profile>() }
        // No bundled/demo/public server credentials. Import a profile you own or are
        // authorized to use; this avoids selecting expired or untrusted endpoints.
        LaunchedEffect(Unit) {
            imported = "No server imported. Import your own VPN profile or subscription."
        }
        val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            if (uri != null) try {
                contentResolver.openInputStream(uri)?.bufferedReader()?.use { reader ->
                    val text = reader.readText()
                    val parsed = Profile.parseSubscription(text)
                    val added = if (parsed.isNotEmpty()) parsed else listOf(Profile.fromJson(text))
                    profiles.addAll(0, added); selected = added.first()
                    imported = "Imported ${added.size} profile(s)"
                }
            } catch (e: Exception) { dialog = "Import failed: ${e.message}" }
        }
        val vpnPermission = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == RESULT_OK) startSelectedProfile(selected) else { status = "DISCONNECTED"; dialog = "VPN permission was denied." }
        }
        fun connectOrDisconnect() {
            if (connected || busy) {
                startService(Intent(context, SATunnelVpnService::class.java).setAction(SATunnelVpnService.ACTION_STOP))
                connected = false; busy = false; status = "DISCONNECTING"
            } else {
                if (selected.shareLink.isBlank()) { dialog = "Select an imported server URI first. Demo labels do not contain server credentials."; return }
                val permission = VpnService.prepare(context)
                if (permission != null) vpnPermission.launch(permission) else startSelectedProfile(selected)
            }
        }
        val drawerState = rememberDrawerState(DrawerValue.Closed)
        LaunchedEffect(drawer) { if (drawer) drawerState.open() else drawerState.close() }
        MaterialTheme(colorScheme = if (dark) darkColorScheme(primary = Blue) else lightColorScheme(primary = Blue)) {
            ModalNavigationDrawer(
                drawerState = drawerState,
                drawerContent = {
                    ModalDrawerSheet {
                        Text("SA TUNNEL", modifier = Modifier.padding(22.dp), color = Blue, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        NavigationDrawerItem(label = { Text("Dashboard") }, selected = true, onClick = { drawer = false }, icon = { Icon(Icons.Default.Home, null) })
                        NavigationDrawerItem(label = { Text("Enable Dark Theme") }, selected = dark, onClick = { dark = !dark }, icon = { Icon(Icons.Default.Palette, null) })
                        listOf("V2Ray / Protocols", "Custom DNS", "Import Config", "Logs", "Privacy policy").forEach { item ->
                            NavigationDrawerItem(label = { Text(item) }, selected = false, onClick = { drawer = false; dialog = when(item) {
                                "V2Ray / Protocols" -> "VLESS, VMess AEAD, Trojan and supported Hysteria2 share links use the pinned Xray/libXray core. Hysteria2 requires TLS and rejects insecure TLS options. SSH needs a separate SSH client and TUN-to-SOCKS bridge and cannot connect in this build."
                                "Custom DNS" -> "DNS is stored per profile. Use a trusted resolver such as 1.1.1.1 or 8.8.8.8."
                                "Import Config" -> "Import VLESS, VMess AEAD, Trojan or Hysteria2 share links, a URI subscription, or an Xray JSON outbounds file. Legacy VMess QR/Base64 links and SSH connections are not supported."
                                else -> "$item is not configured in this build."
                            } }, icon = { Icon(Icons.Default.Settings, null) })
                        }
                    }
                }
            ) {
                Scaffold(bottomBar = {
                    NavigationBar(containerColor = Blue, contentColor = Color.White) {
                        NavigationBarItem(selected = false, onClick = { dialog = "No update feed configured. Add your trusted HTTPS JSON endpoint in project settings." }, icon = { Icon(Icons.Default.CloudDownload, null) }, label = { Text("UPDATES") })
                        NavigationBarItem(selected = false, onClick = { dialog = "Connection log view is not implemented yet. Current status and engine errors are shown on the dashboard." }, icon = { Icon(Icons.Default.ReceiptLong, null) }, label = { Text("Logs") })
                        NavigationBarItem(selected = false, onClick = { dialog = "Community link not configured." }, icon = { Icon(Icons.Default.Groups, null) }, label = { Text("Join Us") })
                        NavigationBarItem(selected = false, onClick = { dialog = "Use Android Back to leave SA TUNNEL." }, icon = { Icon(Icons.Default.ExitToApp, null) }, label = { Text("Exit") })
                    }
                }) { padding ->
                    Column(Modifier.fillMaxSize().padding(padding).background(MaterialTheme.colorScheme.background).verticalScroll(rememberScrollState())) {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { drawer = true }) { Icon(Icons.Default.Menu, contentDescription = "Menu", tint = Blue) }
                            Text("1.0.0 Build 1", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(Modifier.weight(1f))
                            Text("SA TUNNEL", color = Blue, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.height(18.dp))
                        Image(
                            painter = painterResource(id = R.drawable.ic_sa_logo),
                            contentDescription = "SA TUNNEL logo",
                            modifier = Modifier.align(Alignment.CenterHorizontally).size(164.dp).shadow(8.dp, CircleShape)
                        )
                        Spacer(Modifier.height(20.dp))
                        Row(Modifier.fillMaxWidth().padding(horizontal = 30.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("⇩  0 KB", fontSize = 14.sp); Text("0 KB  ⇧", fontSize = 14.sp)
                        }
                        val statusColor = when {
                            connected -> Color(0xFF00A86B)
                            busy -> Color(0xFFE09A18)
                            status.startsWith("ERROR") -> Color(0xFFD32F2F)
                            else -> Color(0xFFD32F4B)
                        }
                        Text(
                            status,
                            modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
                            textAlign = TextAlign.Center,
                            color = statusColor,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text("Config: ${selected.protocol}  |  ${selected.server}:${selected.port}", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                        Spacer(Modifier.height(30.dp))
                        OutlinedCard(Modifier.fillMaxWidth().padding(horizontal = 22.dp).clickable { dialog = "Location: ${selected.region}" }, border = BorderStroke(2.dp, Teal), shape = RoundedCornerShape(18.dp)) {
                            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.MyLocation, null, tint = Blue, modifier = Modifier.size(30.dp)); Spacer(Modifier.width(14.dp))
                                Column { Text("LOCATION", color = Blue, fontSize = 10.sp); Text(selected.name, fontWeight = FontWeight.Medium); Text(selected.region, fontSize = 12.sp, color = Color.Gray) }
                            }
                        }
                        Spacer(Modifier.height(20.dp))
                        OutlinedCard(Modifier.fillMaxWidth().padding(horizontal = 22.dp).clickable { showProfiles = true }, border = BorderStroke(2.dp, Teal), shape = RoundedCornerShape(18.dp)) {
                            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Security, null, tint = Color(0xFF5A168C), modifier = Modifier.size(34.dp)); Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) { Text("NETWORK", color = Blue, fontSize = 10.sp); Text(selected.name, fontWeight = FontWeight.Medium); Text("${selected.protocol} • ${selected.region}", fontSize = 12.sp, color = Color.Gray) }
                                Icon(Icons.Default.PlaylistAdd, null, tint = Blue)
                            }
                        }
                        Text(imported, modifier = Modifier.fillMaxWidth().padding(top = 7.dp), textAlign = TextAlign.Center, color = Color.Gray, fontSize = 11.sp)
                        Spacer(Modifier.height(38.dp))
                        val buttonColor by animateColorAsState(if (connected) Color(0xFFD32F2F) else Color(0xFF00B85A), label = "button")
                        Box(Modifier.align(Alignment.CenterHorizontally).size(174.dp).background(Color(0xFFB7D0FF), CircleShape).padding(9.dp).background(buttonColor, CircleShape).clickable {
                            connectOrDisconnect()
                        }, contentAlignment = Alignment.Center) {
                            Text(if (connected || busy) "STOP" else "START", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.height(16.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                            TextButton(onClick = { filePicker.launch(arrayOf("*/*")) }) { Icon(Icons.Default.FileOpen, null); Text(" Import JSON profile") }
                        }
                    }
                }
            }
            if (showProfiles) AlertDialog(onDismissRequest = { showProfiles = false }, title = { Text("Select network") }, text = {
                var query by remember { mutableStateOf("") }
                var protocolFilter by remember { mutableStateOf("ALL") }
                val visibleProfiles = profiles.filter {
                    (query.isBlank() || it.name.contains(query, true) || it.region.contains(query, true) || it.server.contains(query, true)) &&
                    (protocolFilter == "ALL" || it.protocol.equals(protocolFilter, true))
                }
                Column {
                    OutlinedTextField(value = query, onValueChange = { query = it }, label = { Text("Search server name / host") }, singleLine = true)
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("ALL", "VLESS", "VMESS", "TROJAN", "HYSTERIA2", "SSH").forEach { proto ->
                            FilterChip(selected = protocolFilter == proto, onClick = { protocolFilter = proto }, label = { Text(proto) })
                        }
                    }
                    Text("${visibleProfiles.size} server profiles", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                    LazyColumn(Modifier.heightIn(max = 430.dp)) {
                        items(visibleProfiles) { p ->
                            ListItem(headlineContent = { Text(p.name) }, supportingContent = { Text("${p.protocol} • ${p.region}") }, trailingContent = { if (p == selected) Icon(Icons.Default.CheckCircle, null, tint = Color(0xFF00B86B)) }, modifier = Modifier.clickable { selected = p; showProfiles = false })
                        }
                    }
                }
            }, confirmButton = { TextButton(onClick = { showProfiles = false }) { Text("Close") } })
            if (dialog.isNotBlank()) AlertDialog(onDismissRequest = { dialog = "" }, title = { Text("SA TUNNEL") }, text = { Text(dialog) }, confirmButton = { TextButton(onClick = { dialog = "" }) { Text("OK") } })
        }
    }
}
